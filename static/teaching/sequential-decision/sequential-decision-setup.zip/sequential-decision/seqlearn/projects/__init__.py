"""Simulators of the projects (see projects/projects.pdf)."""
