"""Project 2: Bayesian optimization of the hyperparameters of a small neural network.

`BlackBox.evaluate(x)` trains a one-hidden-layer network with tanh units by mini-batch
gradient descent on a two-dimensional classification problem (two interleaved spirals), and
returns its error rate on a validation set. The point x lies in [0, 1]^4 and encodes:

  x[0]  learning rate          10 ** (-3 + 3 x[0]),   from 0.001 to 1
  x[1]  weight decay           10 ** (-6 + 5 x[1]),   from 1e-6 to 0.1
  x[2]  number of hidden units round(2 ** (2 + 4 x[2])), from 4 to 64
  x[3]  batch size             round(2 ** (3 + 4 x[3])), from 8 to 128

Each evaluation is noisy (random initialization and order of the examples), costs about
0.1 to 0.5 second, and is counted. `epochs` sets the length of the training: fewer epochs
give a cheaper but less accurate evaluation.
"""

import numpy as np

DIM = 4
BUDGET = 40
EPOCHS = 30


def spirals(n, noise, rng):
    """`n` points of two interleaved spirals, with labels 0 and 1."""
    labels = rng.integers(2, size=n)
    t = np.sqrt(rng.random(n)) * 3 * np.pi
    angle = t + np.pi * labels
    points = np.stack([t * np.cos(angle), t * np.sin(angle)], axis=1) / (3 * np.pi)
    return points + noise * rng.standard_normal((n, 2)), labels.astype(float)


def decode(x):
    """Hyperparameters encoded by the point x of [0, 1]^4."""
    x = np.clip(np.asarray(x, dtype=float), 0, 1)
    return {"learning_rate": 10 ** (-3 + 3 * x[0]), "weight_decay": 10 ** (-6 + 5 * x[1]),
            "hidden": int(round(2 ** (2 + 4 * x[2]))), "batch_size": int(round(2 ** (3 + 4 * x[3])))}


def train_and_validate(params, data, epochs, rng):
    X, y, X_val, y_val = data
    h, lr, wd, bs = params["hidden"], params["learning_rate"], params["weight_decay"], params["batch_size"]
    W1 = rng.standard_normal((2, h)) * 1.5
    b1 = np.zeros(h)
    w2 = rng.standard_normal(h) / np.sqrt(h)
    b2 = 0.0
    for _ in range(epochs):
        order = rng.permutation(len(X))
        for start in range(0, len(X), bs):
            idx = order[start:start + bs]
            A = np.tanh(X[idx] @ W1 + b1)
            p = 1 / (1 + np.exp(-np.clip(A @ w2 + b2, -30, 30)))
            g = (p - y[idx]) / len(idx)
            gA = np.outer(g, w2) * (1 - A ** 2)
            w2 -= lr * (A.T @ g + wd * w2)
            b2 -= lr * g.sum()
            W1 -= lr * (X[idx].T @ gA + wd * W1)
            b1 -= lr * gA.sum(axis=0)
    scores = np.tanh(X_val @ W1 + b1) @ w2 + b2
    return float(np.mean((scores > 0) != (y_val > 0.5)))


class BlackBox:
    """Validation error of the network, as a function of x in [0, 1]^4."""

    def __init__(self, rng=None):
        self.rng = np.random.default_rng(rng)
        data_rng = np.random.default_rng(2026)
        X, y = spirals(600, 0.04, data_rng)
        X_val, y_val = spirals(600, 0.04, data_rng)
        self.data = (X, y, X_val, y_val)
        self.n_evaluations = 0
        self.cost = 0.0

    def evaluate(self, x, epochs=EPOCHS):
        """Train with the hyperparameters encoded by x and return the validation error."""
        self.n_evaluations += 1
        self.cost += epochs / EPOCHS
        return train_and_validate(decode(x), self.data, epochs, self.rng)
