"""Project 3: exploration in reinforcement learning.

Two MDPs where undirected exploration fails, as `TabularMDP` objects (see seqlearn.mdp):
`make_riverswim` and `make_slippery_maze`. An episode starts at `env.reset()` and lasts
`EPISODE_LENGTH` steps (the river has no terminal state) or until a terminal state is
reached. The discount factor is GAMMA.
"""

import numpy as np

from ..mdp import GridWorld, TabularMDP

GAMMA = 0.95
EPISODE_LENGTH = 50
LEFT, RIGHT = 0, 1

SLIPPERY_MAZE = [
    "S.g.#.......",
    ".##.#.####..",
    ".#..#....#..",
    ".#.###.#.#..",
    ".#.....#.#..",
    ".####.##.##.",
    "......#....G",
]


def make_riverswim(n_states=6, rng=None):
    """RiverSwim (Strehl and Littman, 2008). States 0 to n-1 along a river, actions LEFT and
    RIGHT. LEFT always moves one state to the left (downstream). RIGHT swims upstream: it
    moves right with probability 0.35, stays with probability 0.6 and moves left with
    probability 0.05; at both ends, the moves that would leave the river stay in place.
    Reward 0.005 for LEFT in state 0, and 1 for RIGHT in the last state."""
    n = n_states
    P = np.zeros((n, 2, n))
    R = np.zeros((n, 2))
    for s in range(n):
        P[s, LEFT, max(s - 1, 0)] = 1.0
        P[s, RIGHT, min(s + 1, n - 1)] += 0.35
        P[s, RIGHT, s] += 0.6
        P[s, RIGHT, max(s - 1, 0)] += 0.05
    R[0, LEFT] = 0.005
    R[n - 1, RIGHT] = 1.0
    return TabularMDP(P, R, start=0, rng=rng)


def make_slippery_maze(rng=None):
    """Maze with a small reward g (0.05) next to the start and the goal G (+1) far away; each
    move goes in a random direction with probability 0.2."""
    return GridWorld(SLIPPERY_MAZE, step=0.0, goal=1.0, small_goal=0.05, slip=0.2, rng=rng)


def policy_value(env, policy, gamma=GAMMA):
    """Exact value V^pi of a deterministic policy (one action per state), by solving the
    Bellman equations."""
    n = env.n_states
    P_pi = env.P[np.arange(n), policy]
    r_pi = env.R[np.arange(n), policy]
    return np.linalg.solve(np.eye(n) - gamma * P_pi, r_pi)
