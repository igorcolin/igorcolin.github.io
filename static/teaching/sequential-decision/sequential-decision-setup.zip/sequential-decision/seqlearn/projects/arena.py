"""Project 4: a model arena.

N_MODELS models compete in duels judged by annotators. Model i beats model j with
probability

    P[i, j] = (1 - noise) * sigmoid(s_i - s_j + c * (u_i v_j - u_j v_i)) + noise / 2,

where s are Bradley-Terry scores, the term in c makes some preferences cyclic, and a
proportion `noise` of the annotators answers at random. The quality of a model is its Borda
score, its mean probability of beating the other models: `true_top(k)` returns the k best
models for this score, used to evaluate the agents (unknown to them).
"""

import numpy as np

N_MODELS = 20
TOP_K = 3


def sigmoid(z):
    return 1 / (1 + np.exp(-z))


class ProjectArena:
    def __init__(self, rng=None, n_models=N_MODELS, intransitivity=0.6, noise=0.1):
        rng = np.random.default_rng(rng)
        self.n_models = n_models
        s = rng.normal(0, 1, n_models)
        u, v = rng.normal(0, 1, n_models), rng.normal(0, 1, n_models)
        cyclic = intransitivity * (np.outer(u, v) - np.outer(v, u))
        self.P = (1 - noise) * sigmoid(s[:, None] - s[None, :] + cyclic) + noise / 2
        np.fill_diagonal(self.P, 0.5)
        self.rng = rng
        self.n_duels = 0

    @property
    def borda(self):
        return (self.P.sum(axis=1) - 0.5) / (self.n_models - 1)

    def true_top(self, k=TOP_K):
        return set(np.argsort(-self.borda)[:k].tolist())

    def duel(self, i, j):
        """One duel between models i and j: return 1.0 if i wins and 0.0 otherwise."""
        if i == j:
            raise ValueError("A model cannot duel itself.")
        self.n_duels += 1
        return float(self.rng.random() < self.P[i, j])


def make_arena(rng=None):
    return ProjectArena(rng)
