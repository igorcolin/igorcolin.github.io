"""Project 1: recommendation under drift.

At each round a user arrives with a profile over N_MOODS moods, and the agent recommends one
of N_ITEMS items. Item a is clicked with probability <profile, appeal[a]>, as in the track
`users` of Lab 4: the feature vector of item a is the profile written in block a, of
dimension DIM = N_ITEMS * N_MOODS. The appeals change at N_CHANGES unknown rounds, where a
random part of the items gets new appeals.
"""

import numpy as np

from ..linear import LinearBandit

N_ITEMS, N_MOODS = 10, 5
DIM = N_ITEMS * N_MOODS
HORIZON = 20_000
N_CHANGES = 4


class DriftingRecommendation(LinearBandit):
    """Recommendation with user profiles whose click rates change at unknown rounds."""

    def __init__(self, rng=None, horizon=HORIZON, n_changes=N_CHANGES):
        rng = np.random.default_rng(rng)
        self.horizon = horizon
        self.n_arms = N_ITEMS
        appeal = rng.beta(0.7, 2.0, size=(N_ITEMS, N_MOODS))
        self.change_points = np.sort(rng.choice(np.arange(horizon // 10, horizon), n_changes, replace=False))
        self.appeals = [appeal]
        for _ in range(n_changes):
            appeal = appeal.copy()
            changed = rng.random(N_ITEMS) < 0.5
            appeal[changed] = rng.beta(0.7, 2.0, size=(changed.sum(), N_MOODS))
            self.appeals.append(appeal)
        super().__init__(self.appeals[0].ravel(), rng)
        self.t = 0
        self._new_user()

    def _new_user(self):
        self.profile = self.rng.dirichlet(0.3 * np.ones(N_MOODS))
        self._features = np.kron(np.eye(N_ITEMS), self.profile)

    def _next_round(self):
        self.t += 1
        period = np.searchsorted(self.change_points, self.t, side="right")
        self.theta = self.appeals[period].ravel()
        self._new_user()

    def features(self):
        return self._features


def make_env(rng=None):
    return DriftingRecommendation(rng)


def uniform_logs(n, rng=None):
    """Logs of a uniformly random recommender on a new environment, for `n` rounds: a
    dictionary of arrays "features" (n, N_ITEMS, DIM), "items" (n,) and "clicks" (n,). The
    propensity of every logged item is 1 / N_ITEMS."""
    rng = np.random.default_rng(rng)
    env = DriftingRecommendation(rng, horizon=n)
    features = np.empty((n, N_ITEMS, DIM))
    items = rng.integers(N_ITEMS, size=n)
    clicks = np.empty(n)
    for t in range(n):
        features[t] = env.features()
        clicks[t] = env.pull(items[t])
    return {"features": features, "items": items, "clicks": clicks}


def uniform_log_stream(n, rng=None):
    """The same logs as `uniform_logs`, generated one at a time (no memory cost): yields
    (features, item, click) for `n` rounds of a uniformly random recommender on a new
    environment, whose change points are spread over the n rounds."""
    rng = np.random.default_rng(rng)
    env = DriftingRecommendation(rng, horizon=n)
    for _ in range(n):
        features = env.features()
        item = int(rng.integers(N_ITEMS))
        yield features, item, env.pull(item)
