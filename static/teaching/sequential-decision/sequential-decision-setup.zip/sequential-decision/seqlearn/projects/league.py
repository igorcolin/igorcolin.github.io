"""Project 5: rating the players of a team game.

An online game opposes two teams of TEAM_SIZE players. The league has N_ACTIVE active players;
each player i has a strength s_i (hidden), and team A beats team B with probability

    sigmoid(sum of the strengths of A - sum of the strengths of B).

The strengths move: they follow a slow random walk; after each match played, a player leaves
the league with probability CHURN and is replaced by a newcomer, whose strength starts low and
grows towards its potential over about 50 matches (a few newcomers are strong from the start:
experienced players with a new account). Some players queue in parties of 2 or 3 friends, who
always play in the same team.

At each round, `queue()` returns the players waiting for a match; the matchmaker forms two teams
from them and calls `play(team_a, team_b)`. The attributes `strength` and `active` are for the
evaluation only: the agents must not read them.
"""

import numpy as np

TEAM_SIZE = 5
N_ACTIVE = 200
QUEUE_SIZE = 30
N_MATCHES = 20000
CHURN = 0.002
DRIFT = 0.03
STRENGTH_SD = 0.5
CAPACITY = 5000


def sigmoid(z):
    return 1 / (1 + np.exp(-z))


class League:
    def __init__(self, rng=None, n_active=N_ACTIVE, churn=CHURN, drift=DRIFT, party_rate=0.3,
                 smurf_rate=0.05):
        self.rng = np.random.default_rng(rng)
        self.churn, self.drift, self.smurf_rate = churn, drift, smurf_rate
        self.potential = np.zeros(CAPACITY)
        self.offset = np.zeros(CAPACITY)
        self.age = np.zeros(CAPACITY)
        self.party_of = -np.ones(CAPACITY, dtype=int)
        self.parties = []
        self.n_players = 0
        self.slots = [self._new_player(newcomer=False) for _ in range(n_active)]
        players = list(self.rng.permutation(n_active))
        n_grouped = 0
        while n_grouped < party_rate * n_active:
            size = int(self.rng.integers(2, 4))
            group = [int(players.pop()) for _ in range(size)]
            self.party_of[group] = len(self.parties)
            self.parties.append(group)
            n_grouped += size
        self.n_matches = 0

    def _new_player(self, newcomer=True):
        i = self.n_players
        if i == CAPACITY:
            raise RuntimeError("Too many players: increase CAPACITY.")
        self.n_players += 1
        self.potential[i] = self.rng.normal(0, STRENGTH_SD)
        if newcomer and self.rng.random() < self.smurf_rate:
            self.potential[i] = abs(self.potential[i]) + 2 * STRENGTH_SD
        elif newcomer:
            self.offset[i] = -2 * STRENGTH_SD
        return i

    @property
    def active(self):
        """Ids of the active players (evaluation only)."""
        return np.array(self.slots)

    @property
    def strength(self):
        """Current strength of every player id, active or not (evaluation only)."""
        n = self.n_players
        return self.potential[:n] + self.offset[:n] * np.exp(-self.age[:n] / 25)

    def party(self, i):
        """The party of player i (a list of ids, [i] if i plays alone). Public information."""
        p = self.party_of[i]
        return [int(i)] if p < 0 else list(self.parties[p])

    def queue(self):
        """Players waiting for a match: QUEUE_SIZE ids, with complete parties."""
        waiting, seen = [], set()
        for k in self.rng.permutation(len(self.slots)):
            i = self.slots[k]
            if i in seen:
                continue
            group = self.party(i)
            seen.update(group)
            if len(waiting) + len(group) <= QUEUE_SIZE:
                waiting += group
            if len(waiting) == QUEUE_SIZE:
                break
        return waiting

    def win_probability(self, team_a, team_b):
        """Probability that team_a wins (evaluation only)."""
        s = self.strength
        return float(sigmoid(s[list(team_a)].sum() - s[list(team_b)].sum()))

    def play(self, team_a, team_b):
        """Play a match: return 1.0 if team_a wins, 0.0 otherwise."""
        team_a, team_b = [int(i) for i in team_a], [int(i) for i in team_b]
        players = team_a + team_b
        if len(team_a) != TEAM_SIZE or len(team_b) != TEAM_SIZE or len(set(players)) != 2 * TEAM_SIZE:
            raise ValueError(f"Two teams of {TEAM_SIZE} distinct players are needed.")
        if not set(players) <= set(self.slots):
            raise ValueError("Only active players can play.")
        for team in (team_a, team_b):
            for i in team:
                if not set(self.party(i)) <= set(team):
                    raise ValueError(f"The party of player {i} must play in the same team.")
        y = float(self.rng.random() < self.win_probability(team_a, team_b))
        self.n_matches += 1
        self.age[players] += 1
        n = self.n_players
        self.potential[:n] += self.drift * self.rng.standard_normal(n) / np.sqrt(len(self.slots))
        for i in players:
            if self.rng.random() < self.churn:
                self._leave(i)
        return y

    def _leave(self, i):
        p = self.party_of[i]
        if p >= 0:
            self.parties[p].remove(i)
            if len(self.parties[p]) == 1:
                self.party_of[self.parties[p][0]] = -1
            self.party_of[i] = -1
        self.slots[self.slots.index(i)] = self._new_player()


def make_league(rng=None):
    return League(rng)
