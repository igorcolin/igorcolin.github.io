"""Cart-pole balancing and softmax policies with linear features (Lab 8)."""

import matplotlib.pyplot as plt
import numpy as np

from .plotting import COLORS, MUTED, TEXT


class CartPole:
    """Cart-pole balancing (Barto, Sutton and Anderson, 1983), with the constants of Gymnasium.

    The state is (x, x_dot, theta, theta_dot): position and speed of the cart, angle of the
    pole (0 is upright) and its angular speed. Action 0 pushes the cart to the left, action 1
    to the right. Each step gives a reward 1, including the last one; the episode ends when
    |theta| > 12 degrees or |x| > 2.4 (failure), or after `max_steps` steps.
    """

    gravity, mass_cart, mass_pole, half_length, force, tau = 9.8, 1.0, 0.1, 0.5, 10.0, 0.02
    theta_max, x_max = 12 * np.pi / 180, 2.4
    n_actions, n_features = 2, 4

    def __init__(self, max_steps=500, rng=None):
        self.max_steps = max_steps
        self.rng = np.random.default_rng(rng)
        self.state = None

    def reset(self):
        self.state = self.rng.uniform(-0.05, 0.05, size=4)
        self.t = 0
        return self.state.copy()

    def step(self, action):
        """Play `action` (0 or 1): return (next state, reward, done)."""
        x, x_dot, theta, theta_dot = self.state
        force = self.force if action == 1 else -self.force
        cos, sin = np.cos(theta), np.sin(theta)
        total = self.mass_cart + self.mass_pole
        pole_ml = self.mass_pole * self.half_length
        temp = (force + pole_ml * theta_dot**2 * sin) / total
        theta_acc = (self.gravity * sin - cos * temp) / (
            self.half_length * (4.0 / 3.0 - self.mass_pole * cos**2 / total))
        x_acc = temp - pole_ml * theta_acc * cos / total
        x, x_dot = x + self.tau * x_dot, x_dot + self.tau * x_acc
        theta, theta_dot = theta + self.tau * theta_dot, theta_dot + self.tau * theta_acc
        self.state = np.array([x, x_dot, theta, theta_dot])
        self.t += 1
        failed = abs(x) > self.x_max or abs(theta) > self.theta_max
        return self.state.copy(), 1.0, bool(failed or self.t >= self.max_steps)

    def draw(self, ax, state, title=None):
        """Draw the cart and the pole in `state`."""
        x, theta = state[0], state[2]
        ax.plot([-self.x_max - 0.4, self.x_max + 0.4], [0, 0], color=MUTED, lw=1)
        for edge in (-self.x_max, self.x_max):
            ax.plot([edge, edge], [-0.05, 0.05], color=MUTED, lw=1)
        ax.add_patch(plt.Rectangle((x - 0.25, 0), 0.5, 0.25, color=COLORS[0]))
        top = (x + 2 * self.half_length * np.sin(theta), 0.25 + 2 * self.half_length * np.cos(theta))
        ax.plot([x, top[0]], [0.25, top[1]], color=COLORS[1], lw=4, solid_capstyle="round")
        ax.set_xlim(-self.x_max - 0.5, self.x_max + 0.5)
        ax.set_ylim(-0.2, 1.4)
        ax.set_aspect("equal")
        ax.set_xticks([])
        ax.set_yticks([])
        ax.grid(False)
        for spine in ax.spines.values():
            spine.set_visible(False)
        if title:
            ax.set_title(title, color=TEXT)


# Typical magnitudes of the four coordinates of the state, used to scale the features.
SCALE = np.array([2.4, 3.0, 0.21, 3.0])


def quadratic_features(state):
    """Features (1, u_i, u_i u_j for i <= j) of a state, where u = state / SCALE, for value
    functions (15 features for the cart-pole)."""
    state = np.asarray(state, dtype=float) / SCALE
    i, j = np.triu_indices(len(state))
    return np.concatenate([[1.0], state, state[i] * state[j]])


def run_policy(env, act, n_episodes=1, rng=None):
    """Lengths of `n_episodes` episodes where the action in state s is `act(s, rng)`."""
    rng = np.random.default_rng(rng)
    lengths = []
    for _ in range(n_episodes):
        state, done, steps = env.reset(), False, 0
        while not done:
            state, _, done = env.step(act(state, rng))
            steps += 1
        lengths.append(steps)
    return np.array(lengths)
