"""Automatic tests for the labs. Each function raises AssertionError with an explicit message."""

import numpy as np

from .bandits import Bandit, run


class _FixedBandit(Bandit):
    """Deterministic bandit: arm a always pays means[a]."""

    def pull(self, arm):
        return float(self.means[arm])


class _DecayBandit(Bandit):
    """Arm 0 pays 1 at its first pull and 0 afterwards; arm 1 always pays 0.5."""

    def __init__(self):
        super().__init__([0.0, 0.5])
        self._first = True

    def pull(self, arm):
        if arm == 1:
            return 0.5
        reward, self._first = float(self._first), False
        return reward


def _arms(agent, env, horizon):
    arms, _ = run(env, agent, horizon)
    return arms.tolist()


def _ok(name):
    print(f"{name}: all tests passed.")


def check_pseudo_regret(pseudo_regret):
    gaps = np.array([0.0, 0.1, 0.3])
    arms = np.array([0, 1, 1, 2])
    expected = np.array([0.0, 0.1, 0.2, 0.5])
    out = pseudo_regret(arms, gaps)
    assert out is not None, "pseudo_regret returns nothing."
    assert np.allclose(out, expected), (
        f"For arms={arms.tolist()} and gaps={gaps.tolist()}, "
        f"expected {expected.tolist()}, got {np.asarray(out).tolist()}."
    )
    batch = np.stack([arms, arms[::-1]])
    out = pseudo_regret(batch, gaps)
    assert np.shape(out) == (2, 4), "For arms of shape (n_runs, T), the output must have the same shape."
    assert np.allclose(out, [expected, [0.3, 0.4, 0.5, 0.5]]), (
        "The cumulative sum must run along the last axis (time)."
    )
    _ok("pseudo_regret")


def check_greedy(GreedyAgent):
    got = _arms(GreedyAgent(3), _FixedBandit([0.2, 0.8, 0.5]), 6)
    assert got == [0, 1, 2, 1, 1, 1], (
        f"Noiseless means (0.2, 0.8, 0.5): expected [0, 1, 2, 1, 1, 1], got {got}. "
        "Each arm must be pulled once, in order, before taking the argmax."
    )
    got = _arms(GreedyAgent(2), _FixedBandit([0.5, 0.5]), 4)
    assert got == [0, 1, 0, 0], (
        f"Equal means: expected [0, 1, 0, 0], got {got}. Ties must go to the smallest index."
    )
    agent = GreedyAgent(2)
    _arms(agent, _FixedBandit([0.9, 0.1]), 5)
    got = _arms(agent, _FixedBandit([0.1, 0.9]), 4)
    assert got == [0, 1, 1, 1], "reset() must bring the agent back to its initial state."
    _ok("GreedyAgent")


def check_epsilon_greedy(EpsilonGreedyAgent):
    got = _arms(EpsilonGreedyAgent(3, 0.0), _FixedBandit([0.2, 0.8, 0.5]), 6)
    assert got == [0, 1, 2, 1, 1, 1], f"With epsilon = 0, the agent must behave like greedy: got {got}."
    horizon = 4002
    arms = np.array(_arms(EpsilonGreedyAgent(3, 1.0, rng=0), _FixedBandit([0.2, 0.8, 0.5]), horizon))
    freqs = np.bincount(arms[3:], minlength=3) / (horizon - 3)
    assert np.allclose(freqs, 1 / 3, atol=0.04), (
        f"With epsilon = 1, arms must be uniform: frequencies {freqs.round(3)}."
    )
    arms = np.array(_arms(EpsilonGreedyAgent(2, 0.3, rng=0), _FixedBandit([0.0, 1.0]), horizon))
    freq = np.mean(arms[2:] == 0)
    assert abs(freq - 0.15) < 0.03, (
        "With epsilon = 0.3 and two arms, the bad arm must be played about 15% of the time "
        f"(uniform exploration, hence epsilon / 2): got {100 * freq:.1f}%."
    )
    _ok("EpsilonGreedyAgent")


def check_etc(ETCAgent):
    got = _arms(ETCAgent(3, 2), _FixedBandit([0.3, 0.7, 0.5]), 9)
    assert got == [0, 1, 2, 0, 1, 2, 1, 1, 1], (
        f"ETC(m=2) on (0.3, 0.7, 0.5): expected [0, 1, 2, 0, 1, 2, 1, 1, 1], got {got}. "
        "During exploration, arms are played in turn."
    )
    got = _arms(ETCAgent(2, 3), _FixedBandit([0.5, 0.5]), 8)
    assert got == [0, 1, 0, 1, 0, 1, 0, 0], (
        f"Equal means: expected [0, 1, 0, 1, 0, 1, 0, 0], got {got}. Ties must go to the smallest index."
    )
    got = _arms(ETCAgent(2, 1), _DecayBandit(), 6)
    assert got == [0, 1, 0, 0, 0, 0], (
        f"Expected [0, 1, 0, 0, 0, 0], got {got}. After exploration, ETC plays the same arm "
        "until the end, even if the empirical means change."
    )
    _ok("ETCAgent")


# ---------------------------------------------------------------------------
# Lab 2

def check_ucb(UCBAgent):
    agent = UCBAgent(2, alpha=2.0)
    for arm, reward in [(0, 1.0), (1, 0.0), (0, 0.0)]:
        agent.update(arm, reward)
    out = agent.index()
    assert out is not None, "index returns nothing."
    assert np.shape(out) == (2,), f"index must return an array of length n_arms: got shape {np.shape(out)}."
    expected = np.array([0.5, 0.0]) + np.sqrt(2.0 * np.log(4) / np.array([2, 1]))
    shifted = np.array([0.5, 0.0]) + np.sqrt(2.0 * np.log(3) / np.array([2, 1]))
    assert not np.allclose(out, shifted), (
        "After 3 rounds, the index is the one of round t = 4: the logarithm is log(self.t + 1), "
        "not log(self.t)."
    )
    assert not np.allclose(out, [0.5, 0.0]), "The index is the empirical mean alone: the bonus is missing."
    assert np.allclose(out, expected), (
        f"After the pulls (arm 0, reward 1), (arm 1, reward 0), (arm 0, reward 0), with alpha = 2, "
        f"expected {expected.round(3).tolist()}, got {np.asarray(out).round(3).tolist()}."
    )
    agent = UCBAgent(2, alpha=0.5)
    for arm, reward in [(0, 1.0), (1, 0.0), (0, 0.0)]:
        agent.update(arm, reward)
    expected = np.array([0.5, 0.0]) + np.sqrt(0.5 * np.log(4) / np.array([2, 1]))
    assert np.allclose(agent.index(), expected), (
        f"With alpha = 0.5, expected {expected.round(3).tolist()}, "
        f"got {np.asarray(agent.index()).round(3).tolist()}. The bonus must depend on self.alpha."
    )
    got = _arms(UCBAgent(3, alpha=2.0), _FixedBandit([0.2, 0.8, 0.5]), 3)
    assert got == [0, 1, 2], f"During the first K rounds, each arm must be pulled once, in order: got {got}."
    got = _arms(UCBAgent(3, alpha=2.0), _FixedBandit([0.2, 0.8, 0.5]), 12)
    expected = [0, 1, 2, 1, 2, 1, 0, 1, 2, 1, 1, 2]
    assert got == expected, (
        f"Noiseless means (0.2, 0.8, 0.5), alpha = 2: expected {expected}, got {got}. "
        "After the first K rounds, play the argmax of the index."
    )
    got = _arms(UCBAgent(2, alpha=0.5), _FixedBandit([0.9, 0.1]), 14)
    expected = [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]
    assert got == expected, f"Noiseless means (0.9, 0.1), alpha = 0.5: expected {expected}, got {got}."
    agent = UCBAgent(2, alpha=2.0)
    _arms(agent, _FixedBandit([0.9, 0.1]), 5)
    got = _arms(agent, _FixedBandit([0.1, 0.9]), 4)
    assert got == [0, 1, 1, 1], "reset() must bring the agent back to its initial state."
    _ok("UCBAgent")


# ---------------------------------------------------------------------------
# Lab 3

def _feed(agent, history):
    for arm, reward in history:
        agent.update(arm, reward)


def check_thompson(ThompsonAgent):
    agent = ThompsonAgent(2, rng=0)
    _feed(agent, [(0, 1.0), (0, 1.0), (0, 0.0), (1, 0.0)])
    out = agent.posterior()
    assert out is not None and len(out) == 2, "posterior must return the pair (alpha, beta)."
    alpha, beta = np.asarray(out[0], dtype=float), np.asarray(out[1], dtype=float)
    assert alpha.shape == (2,) and beta.shape == (2,), "alpha and beta must be arrays of length n_arms."
    assert np.allclose(alpha, [3, 1]) and np.allclose(beta, [2, 2]), (
        "After 2 successes and 1 failure on arm 0, and 1 failure on arm 1, with uniform priors, "
        f"expected alpha = [3, 1] and beta = [2, 2], got alpha = {alpha.tolist()} and beta = {beta.tolist()}."
    )
    agent = ThompsonAgent(3, rng=0)
    draws = np.array([agent.act() for _ in range(3000)])
    assert np.all(np.isin(draws, [0, 1, 2])), "act() must return an arm index."
    freqs = np.bincount(draws, minlength=3) / len(draws)
    assert np.allclose(freqs, 1 / 3, atol=0.04), (
        f"Before any observation, the three arms must be played with the same probability: frequencies {freqs.round(3)}. "
        "Thompson sampling has no initialization rounds."
    )
    agent = ThompsonAgent(2, rng=0)
    _feed(agent, [(0, 1.0)] * 60 + [(1, 0.0)] * 60)
    draws = [agent.act() for _ in range(200)]
    assert all(arm == 0 for arm in draws), "After 60 successes on arm 0 and 60 failures on arm 1, arm 0 must always be played."
    agent = ThompsonAgent(2, rng=0)
    _feed(agent, [(0, 1.0), (1, 0.0)])
    freq = np.mean([agent.act() == 0 for _ in range(6000)])
    assert abs(freq - 5 / 6) < 0.02, (
        "After one success on arm 0 and one failure on arm 1, arm 0 must be played with probability 5/6 "
        f"(Tutorial 3, exercise 1): got {freq:.3f}."
    )
    first, second = ThompsonAgent(2, rng=7), ThompsonAgent(2, rng=7)
    assert [first.act() for _ in range(50)] == [second.act() for _ in range(50)], (
        "Two agents with the same seed must make the same choices: use self.rng for all random draws."
    )
    _ok("ThompsonAgent")


def _ridge_data():
    rng = np.random.default_rng(0)
    xs = rng.standard_normal((6, 3))
    rs = rng.random(6)
    lam = 2.0
    V = lam * np.eye(3) + xs.T @ xs
    b = xs.T @ rs
    return xs, rs, lam, V, b


def check_ridge(Ridge):
    xs, rs, lam, V, b = _ridge_data()
    ridge = Ridge(3, lam)
    assert np.allclose(ridge.V_inv, np.eye(3) / lam), "Before any observation, V_inv must be the identity divided by lam."
    assert np.allclose(ridge.theta_hat, 0), "Before any observation, theta_hat must be zero."
    for x, r in zip(xs, rs):
        ridge.update(x, r)
    assert np.allclose(ridge.V_inv, np.linalg.inv(V)), (
        "After 6 updates, V_inv differs from the inverse of lam * I + sum of x x^T: check the Sherman-Morrison update."
    )
    assert np.allclose(ridge.b, b), "After 6 updates, b must be the sum of the r x."
    assert np.allclose(ridge.theta_hat, np.linalg.solve(V, b)), "theta_hat must be V_inv @ b, recomputed after each update."
    X = np.array([[1.0, 0.0, 0.0], [0.0, 2.0, 0.0], [1.0, 1.0, 1.0], [0.5, -1.0, 2.0]])
    out = ridge.width(X)
    assert out is not None, "width returns nothing."
    expected = np.sqrt(np.sum(X @ np.linalg.inv(V) * X, axis=1))
    assert np.shape(out) == (4,), f"For features of shape (4, 3), width must return an array of length 4: got shape {np.shape(out)}."
    assert np.allclose(out, expected), (
        f"width must return sqrt(x^T V_inv x) for each row x: expected {expected.round(3).tolist()}, got {np.asarray(out).round(3).tolist()}."
    )
    _ok("Ridge")


_LIN_HISTORY = [([1.0, 0.0], 1.0), ([1.0, 0.0], 1.0), ([1.0, 0.0], 0.0), ([1.0, 0.0], 0.0), ([0.0, 1.0], 0.0)]
_LIN_FEATURES = np.array([[1.0, 0.0], [0.0, 1.0], [1.0, 1.0]])


def _feed_linear(agent):
    for x, reward in _LIN_HISTORY:
        agent.update(np.array(x), 0, reward)


def check_linucb(LinUCBAgent):
    agent = LinUCBAgent(2, beta=1.0, lam=1.0)
    out = agent.index(np.array([[1.0, 0.0], [2.0, 0.0]]))
    assert out is not None, "index returns nothing."
    assert np.allclose(out, [1.0, 2.0]), (
        f"Before any observation, with beta = 1 and lam = 1, the index of x is its norm: expected [1, 2], got {np.asarray(out).round(3).tolist()}."
    )
    _feed_linear(agent)
    out = np.asarray(agent.index(_LIN_FEATURES))
    expected = np.array([0.4 + np.sqrt(0.2), np.sqrt(0.5), 0.4 + np.sqrt(0.7)])
    assert np.allclose(out, expected), (
        "Example of Tutorial 3 (exercise 3): V = diag(5, 2), theta_hat = (0.4, 0), beta = 1. "
        f"Expected indices {expected.round(3).tolist()}, got {out.round(3).tolist()}."
    )
    assert agent.act(_LIN_FEATURES) == 2, "On the example of Tutorial 3, LinUCB must play the third arm."
    assert isinstance(agent.act(_LIN_FEATURES), (int, np.integer)), "act() must return an integer."
    agent = LinUCBAgent(2, beta=0.0, lam=1.0)
    _feed_linear(agent)
    assert agent.act(_LIN_FEATURES) == 0, "With beta = 0, the agent plays the argmax of <theta_hat, x>, ties going to the smallest index."
    agent.reset()
    assert np.allclose(agent.index(np.array([[1.0, 0.0]])), 0.0), "reset() must forget the observations."
    _ok("LinUCBAgent")


def check_lints(LinTSAgent):
    agent = LinTSAgent(2, v=0.5, lam=1.0, rng=0)
    _feed_linear(agent)
    samples = np.array([agent.sample() for _ in range(6000)])
    assert samples.shape == (6000, 2), "sample() must return a vector of length dim."
    mean, cov = samples.mean(axis=0), np.cov(samples.T)
    assert np.allclose(mean, [0.4, 0.0], atol=0.02), (
        f"The samples must be centered at theta_hat = (0.4, 0): empirical mean {mean.round(3).tolist()}."
    )
    expected = 0.25 * np.diag([0.2, 0.5])
    assert np.allclose(cov, expected, atol=0.01), (
        "The covariance of the samples must be v^2 V_inv = diag(0.05, 0.125): "
        f"empirical covariance {cov.round(3).tolist()}."
    )
    agent = LinTSAgent(2, v=0.0, lam=1.0, rng=0)
    _feed_linear(agent)
    assert all(agent.act(_LIN_FEATURES[:2]) == 0 for _ in range(20)), "With v = 0, the agent plays the argmax of <theta_hat, x>."
    first, second = LinTSAgent(2, v=1.0, lam=1.0, rng=3), LinTSAgent(2, v=1.0, lam=1.0, rng=3)
    assert [first.act(_LIN_FEATURES) for _ in range(30)] == [second.act(_LIN_FEATURES) for _ in range(30)], (
        "Two agents with the same seed must make the same choices: use self.rng for all random draws."
    )
    _ok("LinTSAgent")


# ---------------------------------------------------------------------------
# Lab 5

def check_hedge(hedge_probs):
    out = hedge_probs(np.zeros(3), 1.0)
    assert out is not None, "hedge_probs returns nothing."
    assert np.allclose(out, 1 / 3), f"With equal cumulative gains, the three probabilities must be 1/3: got {np.asarray(out).round(3).tolist()}."
    gains = np.array([2.0, 1.0, 0.0])
    out = np.asarray(hedge_probs(gains, np.log(2)))
    assert np.allclose(out, [4 / 7, 2 / 7, 1 / 7]), (
        "Tutorial 5, exercise 1: cumulative gains (2, 1, 0) and eta = log 2 give the weights (4, 2, 1), "
        f"so the probabilities (4/7, 2/7, 1/7). Got {out.round(3).tolist()}."
    )
    out = np.asarray(hedge_probs(np.array([5000.0, 4999.0]), 1.0))
    assert np.all(np.isfinite(out)), (
        "With large cumulative gains (5000, 4999), exp overflows: subtract the maximum of eta * gains before "
        "taking the exponential, which does not change the probabilities."
    )
    assert np.allclose(out, [np.e / (1 + np.e), 1 / (1 + np.e)]), f"Gains (5000, 4999), eta = 1: got {out.round(3).tolist()}."
    out = np.asarray(hedge_probs(gains, 0.0))
    assert np.allclose(out, 1 / 3), "With eta = 0, Hedge plays uniformly."
    _ok("hedge_probs")


def check_exp3(EXP3Agent):
    agent = EXP3Agent(3, eta=0.5, rng=0)
    assert np.allclose(agent.loss_hat, 0), "reset() must set loss_hat to zero."
    assert np.allclose(agent.probs(), 1 / 3), "Before any observation, EXP3 plays uniformly."
    agent.p = np.array([0.5, 0.25, 0.25])
    agent.update(1, 0.0)
    assert np.allclose(agent.loss_hat, [0, 4, 0]), (
        "Arm 1, played with probability 0.25, gives reward 0, that is loss 1: its estimated loss must increase by "
        f"1 / 0.25 = 4, and the other estimates must not change. Got loss_hat = {np.asarray(agent.loss_hat).round(3).tolist()}."
    )
    agent.p = np.array([0.5, 0.25, 0.25])
    agent.update(0, 1.0)
    assert np.allclose(agent.loss_hat, [0, 4, 0]), "A reward of 1 is a loss of 0: the estimates must not change."
    assert agent.counts[0] == 1 and agent.t == 2, "update must call super().update(arm, reward), which counts the rounds."
    expected = np.exp(-0.5 * np.array([0, 4, 0]))
    expected /= expected.sum()
    assert np.allclose(agent.probs(), expected), (
        f"probs() must be proportional to exp(-eta * loss_hat): expected {expected.round(3).tolist()}, "
        f"got {np.asarray(agent.probs()).round(3).tolist()}."
    )
    agent = EXP3Agent(2, eta=1.0, rng=0)
    agent.loss_hat = np.array([0.0, np.log(3)])
    draws = np.array([agent.act() for _ in range(6000)])
    assert np.allclose(agent.p, [0.75, 0.25]), "act() must store the probabilities of the round in self.p."
    assert abs(np.mean(draws == 0) - 0.75) < 0.02, (
        f"With probabilities (0.75, 0.25), arm 0 must be played 75% of the time: got {np.mean(draws == 0):.3f}."
    )
    agent = EXP3Agent(2, eta=1.0, rng=0)
    agent.loss_hat = np.array([0.0, 5000.0])
    assert np.all(np.isfinite(agent.probs())), "probs() must not overflow: subtract the minimum of loss_hat first."
    first, second = EXP3Agent(3, 0.1, rng=4), EXP3Agent(3, 0.1, rng=4)
    assert [first.act() for _ in range(40)] == [second.act() for _ in range(40)], (
        "Two agents with the same seed must make the same choices: use self.rng for all random draws."
    )
    _ok("EXP3Agent")


def check_ips(ips):
    logs = {"profiles": np.zeros((4, 2)), "items": np.array([0, 1, 0, 1]),
            "clicks": np.array([1.0, 1.0, 0.0, 1.0]), "propensities": np.array([0.5, 0.25, 0.5, 0.25])}

    def always_zero(profiles):
        return np.tile([1.0, 0.0], (len(profiles), 1))

    def half(profiles):
        return np.full((len(profiles), 2), 0.5)

    out = ips(logs, always_zero)
    assert out is not None, "ips returns nothing."
    assert np.isclose(out, 0.5), (
        "Policy that always plays item 0: the weights are (2, 0, 2, 0) and the clicks (1, 1, 0, 1), so the estimate "
        f"is (2 + 0 + 0 + 0) / 4 = 0.5. Got {float(out):.3f}."
    )
    assert np.isclose(ips(logs, half), (1 + 2 + 0 + 2) / 4), "Policy (0.5, 0.5): the weights are (1, 2, 1, 2)."
    assert np.isclose(ips(logs, half, clip=1.5), (1 + 1.5 + 0 + 1.5) / 4), (
        "With clip = 1.5, the weights (1, 2, 1, 2) become (1, 1.5, 1, 1.5)."
    )
    _ok("ips")


# ---------------------------------------------------------------------------
# Lab 6

class _CountingBandit(Bandit):
    """Deterministic bandit that counts the pulls of each arm: arm a always pays means[a]."""

    def __init__(self, means):
        super().__init__(means)
        self.pulls = np.zeros(self.n_arms, dtype=int)

    def pull(self, arm):
        self.pulls[arm] += 1
        return float(self.means[arm])


def check_uniform_allocation(uniform_allocation):
    env = _CountingBandit([0.2, 0.9, 0.5, 0.4])
    out = uniform_allocation(env, 40)
    assert out is not None, "uniform_allocation returns nothing."
    assert out == 1, f"Noiseless means (0.2, 0.9, 0.5, 0.4): the recommended arm must be 1, got {out}."
    assert env.pulls.tolist() == [10, 10, 10, 10], f"A budget of 40 on 4 arms gives 10 pulls each: got {env.pulls.tolist()}."
    env = _CountingBandit([0.2, 0.9, 0.5])
    uniform_allocation(env, 10)
    assert env.pulls.sum() == 10 and env.pulls.max() - env.pulls.min() <= 1, (
        f"With a budget of 10 on 3 arms, the pulls must be as balanced as possible and sum to 10: got {env.pulls.tolist()}."
    )
    _ok("uniform_allocation")


def check_sequential_halving(sequential_halving):
    env = _CountingBandit([0.3, 0.1, 0.8, 0.6])
    out = sequential_halving(env, 16)
    assert out is not None, "sequential_halving returns nothing."
    assert out == 2, f"Noiseless means (0.3, 0.1, 0.8, 0.6): the recommended arm must be 2, got {out}."
    assert env.pulls.tolist() == [2, 2, 6, 6], (
        "Budget 16, K = 4, so 2 phases of 8 pulls: 2 pulls of each arm, then 4 pulls of arms 2 and 3. "
        f"Expected the pull counts [2, 2, 6, 6], got {env.pulls.tolist()}."
    )
    env = _CountingBandit([0.5, 0.4, 0.3, 0.2, 0.1, 0.0, 0.6, 0.45])
    out = sequential_halving(env, 240)
    assert out == 6, f"Noiseless means with the best arm at index 6: got {out}."
    assert env.pulls.sum() <= 240, f"The budget is 240 pulls, but {env.pulls.sum()} were used."
    assert env.pulls.tolist() == [70, 30, 10, 10, 10, 10, 70, 30], (
        "Budget 240, K = 8, so 3 phases of 80 pulls: 10 pulls of each of the 8 arms, then 20 of each of the 4 best "
        f"(arms 6, 0, 7, 1), then 40 of each of the 2 best (arms 6 and 0). Got {env.pulls.tolist()}."
    )
    _ok("sequential_halving")


def _sigmoid(z):
    return 1 / (1 + np.exp(-z))


def check_bradley_terry(bt_log_likelihood, bt_gradient):
    wins = np.array([[0.0, 6.0], [2.0, 0.0]])
    out = bt_log_likelihood(np.zeros(2), wins)
    assert out is not None, "bt_log_likelihood returns nothing."
    assert np.isclose(out, 8 * np.log(0.5)), f"With equal scores, each of the 8 duels has probability 1/2: expected 8 log(1/2), got {float(out):.4f}."
    s = np.array([np.log(3), 0.0])
    assert np.isclose(bt_log_likelihood(s, wins), 6 * np.log(0.75) + 2 * np.log(0.25)), (
        "Scores (log 3, 0): model 0 wins with probability 3/4, and the log-likelihood is 6 log(3/4) + 2 log(1/4)."
    )
    grad = bt_gradient(s, wins)
    assert grad is not None, "bt_gradient returns nothing."
    assert np.allclose(grad, 0), (
        "Tutorial 6, exercise 2: with 6 wins out of 8, the maximum is at s_0 - s_1 = log 3, where the gradient vanishes. "
        f"Got {np.asarray(grad).round(4).tolist()}."
    )
    rng = np.random.default_rng(0)
    wins = rng.integers(0, 5, (4, 4)).astype(float)
    np.fill_diagonal(wins, 0)
    s = rng.normal(size=4)
    eps = 1e-6
    numeric = np.array([(bt_log_likelihood(s + eps * e, wins) - bt_log_likelihood(s - eps * e, wins)) / (2 * eps) for e in np.eye(4)])
    assert np.allclose(bt_gradient(s, wins), numeric, atol=1e-5), (
        f"bt_gradient differs from the numerical derivative of bt_log_likelihood: expected {numeric.round(3).tolist()}, "
        f"got {np.asarray(bt_gradient(s, wins)).round(3).tolist()}."
    )
    _ok("bt_log_likelihood and bt_gradient")


def check_elo(elo_update):
    ratings = np.zeros(3)
    out = elo_update(ratings, 0, 1, 1.0, 1.0)
    assert out is not None, "elo_update must return the new ratings."
    assert np.allclose(out, [0.5, -0.5, 0.0]), f"Equal ratings, model 0 wins, k = 1: expected [0.5, -0.5, 0], got {np.asarray(out).round(4).tolist()}."
    assert np.allclose(ratings, 0), "elo_update must not modify its argument: work on a copy."
    out = elo_update(np.array([0.5, -0.5, 0.0]), 1, 2, 1.0, 1.0)
    assert np.allclose(out, [0.5, -0.5 + (1 - _sigmoid(-0.5)), -(1 - _sigmoid(-0.5))]), (
        f"Tutorial 6, exercise 2: after B beats C, expected ratings {np.round([0.5, -0.5 + (1 - _sigmoid(-0.5)), -(1 - _sigmoid(-0.5))], 4).tolist()}, "
        f"got {np.asarray(out).round(4).tolist()}."
    )
    out = elo_update(np.array([1.0, 0.0]), 0, 1, 0.0, 0.5)
    assert np.allclose(out, [1.0 - 0.5 * _sigmoid(1.0), 0.5 * _sigmoid(1.0)]), "A loss of model 0 must decrease its rating by k sigmoid(r_0 - r_1)."
    _ok("elo_update")


# ---------------------------------------------------------------------------
# Lab 7

def _three_states():
    """MDP of Tutorial 7: states 0, 1, 2, actions 0 (advance) and 1 (stay or go back)."""
    P = np.zeros((3, 2, 3))
    R = np.zeros((3, 2))
    P[0, 0, 1] = P[0, 1, 0] = 1.0
    R[0, 1] = 1.0
    P[1, 0, 2] = P[1, 1, 0] = 1.0
    P[2, :, 0] = 1.0
    R[2, :] = 4.0
    return P, R


def check_policy_evaluation(policy_evaluation):
    P, R = _three_states()
    out = policy_evaluation(P, R, np.array([0, 0, 0]), 0.5)
    assert out is not None, "policy_evaluation returns nothing."
    v1 = 4 * 0.25 / (1 - 0.125)
    expected = np.array([v1, 2 * v1, 4 + 0.5 * v1])
    assert np.allclose(out, expected), (
        "Tutorial 7: for the policy that always advances, with gamma = 1/2, V(0) = 4 gamma^2 / (1 - gamma^3) = 8/7, "
        f"V(1) = 16/7, V(2) = 32/7. Expected {expected.round(4).tolist()}, got {np.asarray(out).round(4).tolist()}."
    )
    out = policy_evaluation(P, R, np.array([1, 1, 0]), 0.5)
    assert np.isclose(out[0], 2.0), f"The policy that stays in state 0 has V(0) = 1 / (1 - gamma) = 2: got {float(out[0]):.4f}."
    _ok("policy_evaluation")


def check_value_iteration(value_iteration):
    P, R = _three_states()
    out = value_iteration(P, R, 0.5, n_iter=2)
    assert out is not None and len(out) == 2, "value_iteration must return the pair (V, Q)."
    V, Q = out
    assert np.allclose(V, [1.5, 2.0, 4.5]), (
        f"Tutorial 7: two iterations from V = 0 with gamma = 1/2 give V = (1.5, 2, 4.5). Got {np.asarray(V).round(4).tolist()}."
    )
    assert np.shape(Q) == (3, 2), f"Q must have shape (n_states, n_actions): got {np.shape(Q)}."
    assert np.allclose(Q, R + 0.5 * P @ np.array([1.0, 0.0, 4.0])), (
        "Q must be the Q-values of the last iteration, R + gamma P V computed with the V of the previous iteration."
    )
    V, Q = value_iteration(P, R, 0.9, n_iter=500)
    v1 = 4 * 0.81 / (1 - 0.729)
    assert np.allclose(V, [v1, (v1 - 0) / 0.9, 4 + 0.9 * v1], atol=1e-6), (
        "With gamma = 0.9, the optimal policy always advances: V(0) = 4 gamma^2 / (1 - gamma^3). "
        f"Got V = {np.asarray(V).round(3).tolist()}."
    )
    _ok("value_iteration")


def check_qlearning(QLearningAgent):
    agent = QLearningAgent(3, 2, alpha=0.5, gamma=0.5, epsilon=0.0, rng=0)
    assert np.allclose(agent.Q, 0) and np.shape(agent.Q) == (3, 2), "Q must start at zero, with shape (n_states, n_actions)."
    for s, a, r, s_next in [(0, 0, 0.0, 1), (1, 0, 0.0, 2), (2, 0, 4.0, 0), (0, 0, 0.0, 1), (1, 0, 0.0, 2)]:
        agent.update(s, a, r, s_next, False)
    expected = np.zeros((3, 2))
    expected[2, 0], expected[1, 0] = 2.0, 0.5
    assert np.allclose(agent.Q, expected), (
        "Tutorial 7, exercise 2: after the trajectory, Q(2, advance) = 2, Q(1, advance) = 0.5 and the other values are 0. "
        f"Got {np.asarray(agent.Q).round(3).tolist()}."
    )
    agent.update(2, 1, 4.0, 0, True)
    assert np.isclose(agent.Q[2, 1], 2.0), "At the end of an episode (done = True), the target is the reward alone."
    assert agent.act(1) == 0, "With epsilon = 0, act plays the greedy action."
    agent = QLearningAgent(3, 2, alpha=0.5, gamma=0.5, epsilon=1.0, rng=0)
    draws = [agent.act(0) for _ in range(2000)]
    assert abs(np.mean(draws) - 0.5) < 0.05, "With epsilon = 1, act plays uniformly at random."
    first, second = QLearningAgent(3, 2, epsilon=0.5, rng=3), QLearningAgent(3, 2, epsilon=0.5, rng=3)
    assert [first.act(0) for _ in range(50)] == [second.act(0) for _ in range(50)], (
        "Two agents with the same seed must make the same choices: use self.rng for all random draws."
    )
    _ok("QLearningAgent")


# ---------------------------------------------------------------------------
# Lab 0

def check_gaps(gaps):
    out = gaps(np.array([0.5, 0.6, 0.4]))
    assert out is not None, "gaps returns nothing."
    assert np.allclose(out, [0.1, 0.0, 0.2]), (
        f"For means (0.5, 0.6, 0.4), expected [0.1, 0.0, 0.2], got {np.asarray(out).tolist()}."
    )
    _ok("gaps")


def check_counts(counts):
    out = counts(np.array([0, 2, 2, 0, 2]), 4)
    assert out is not None, "counts returns nothing."
    assert np.shape(out) == (4,), (
        f"With n_arms = 4, the output must have length 4, even if an arm is never played: got shape {np.shape(out)}."
    )
    assert np.array_equal(out, [2, 0, 3, 0]), (
        f"For arms [0, 2, 2, 0, 2] and n_arms = 4, expected [2, 0, 3, 0], got {np.asarray(out).tolist()}."
    )
    _ok("counts")


def check_running_mean(running_mean):
    x = np.array([1.0, 0.0, 1.0, 1.0])
    expected = np.array([1.0, 0.5, 2 / 3, 0.75])
    out = running_mean(x)
    assert out is not None, "running_mean returns nothing."
    assert np.allclose(out, expected), (
        f"For x = {x.tolist()}, expected {expected.round(3).tolist()}, got {np.asarray(out).round(3).tolist()}."
    )
    batch = np.stack([x, 1 - x])
    out = running_mean(batch)
    assert np.shape(out) == (2, 4), "For x of shape (n_runs, T), the output must have the same shape."
    assert np.allclose(out, [expected, 1 - expected]), "The running mean must be computed along the last axis (time)."
    _ok("running_mean")


def check_bernoulli(bernoulli):
    out = bernoulli(0.3, 20000, np.random.default_rng(0))
    assert out is not None, "bernoulli returns nothing."
    out = np.asarray(out)
    assert out.shape == (20000,), f"With size = 20000, the output must have shape (20000,): got {out.shape}."
    assert np.all((out == 0) | (out == 1)), "The values must be 0 or 1."
    assert abs(out.mean() - 0.3) < 0.02, f"With p = 0.3, the mean of the draws must be close to 0.3: got {out.mean():.3f}."
    again = np.asarray(bernoulli(0.3, 20000, np.random.default_rng(0)))
    assert np.array_equal(out, again), "Two calls with generators of the same seed must return the same draws: use `rng` for all random draws."
    out = np.asarray(bernoulli(0.5, (3, 7), np.random.default_rng(1)))
    assert out.shape == (3, 7), f"With size = (3, 7), the output must have shape (3, 7): got {out.shape}."
    _ok("bernoulli")


def check_running_mean_class(RunningMean):
    m = RunningMean()
    assert m.n == 0, "A new RunningMean must have n = 0."
    values = []
    for x in [1.0, 0.0, 1.0, 1.0]:
        m.update(x)
        values.append(m.value)
    assert m.n == 4, f"After 4 updates, n must be 4: got {m.n}."
    assert np.allclose(values, [1.0, 0.5, 2 / 3, 0.75]), (
        f"After the updates 1, 0, 1, 1, the successive values must be [1, 0.5, 0.667, 0.75]: got {np.round(values, 3).tolist()}."
    )
    stored = [v for v in vars(m).values() if isinstance(v, (list, np.ndarray)) and np.size(v) > 1]
    assert not stored, "The past observations must not be stored: keep only n and value."
    _ok("RunningMean")


def check_round_robin(RoundRobinAgent):
    got = _arms(RoundRobinAgent(3), _FixedBandit([0.2, 0.8, 0.5]), 7)
    assert got == [0, 1, 2, 0, 1, 2, 0], f"With 3 arms, expected [0, 1, 2, 0, 1, 2, 0], got {got}."
    _ok("RoundRobinAgent")
