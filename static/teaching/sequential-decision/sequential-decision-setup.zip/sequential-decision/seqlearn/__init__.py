"""Lab framework for the Sequential Decision course (ESIEE Paris)."""

# Date of the last change of the package; bump it when any module changes (make_lab_kit.py checks it).
__version__ = "2026.10.30"

from .bandits import (
    Agent,
    Bandit,
    BernoulliBandit,
    GaussianBandit,
    UniformAgent,
    pseudo_regret,
    run,
    run_many,
)
from .agents import UCBAgent
from .plotting import plot_mean
