"""Adversarial sequences of rewards: full information (experts) and bandit feedback."""

import numpy as np


class SequenceBandit:
    """Bandit whose rewards are fixed in advance: pulling arm a at round t pays rewards[t, a].

    No randomness and no means: the sequence can be arbitrary, for instance built against a
    given strategy. The regret is measured against the best fixed arm in hindsight.
    """

    def __init__(self, rewards):
        self.rewards = np.asarray(rewards, dtype=float)
        self.horizon, self.n_arms = self.rewards.shape
        self.t = 0

    def pull(self, arm):
        reward = self.rewards[self.t, arm]
        self.t += 1
        return reward


def alternating_gains(horizon):
    """Gains of two experts: (1/2, 0) at the first round, then (0, 1), (1, 0), (0, 1), ..."""
    gains = np.zeros((horizon, 2))
    gains[0] = [0.5, 0.0]
    gains[1::2, 1] = 1.0
    gains[2::2, 0] = 1.0
    return gains


def stochastic_gains(means, horizon, rng=None):
    """Gains of experts drawn independently from Bernoulli distributions with means `means`."""
    rng = np.random.default_rng(rng)
    return (rng.random((horizon, len(means))) < np.asarray(means)).astype(float)


def regret_vs_best_arm(rewards, received):
    """Cumulative regret against the best fixed arm in hindsight, at each round.

    `rewards` has shape (horizon, n_arms) and `received` (horizon,) or (n_runs, horizon): the
    gains collected by the strategy. The regret at round t is the cumulative reward of the
    best arm over rounds 1..t minus the cumulative gain of the strategy.
    """
    best = np.cumsum(rewards, axis=0).max(axis=1)
    return best - np.cumsum(received, axis=-1)
