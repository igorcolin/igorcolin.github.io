"""Duels between models (Lab 6): Bradley-Terry arena and ranking utilities."""

import numpy as np


def sigmoid(z):
    return 1 / (1 + np.exp(-np.asarray(z, dtype=float)))


class Arena:
    """Duels between `len(scores)` models: model i beats model j with probability
    sigmoid(scores[i] - scores[j]) (Bradley-Terry model). The scores are unknown to the agent.
    """

    def __init__(self, scores, rng=None):
        self.scores = np.asarray(scores, dtype=float)
        self.n_models = len(self.scores)
        self.rng = np.random.default_rng(rng)
        self.n_duels = 0

    @property
    def best(self):
        return int(np.argmax(self.scores))

    def duel(self, i, j):
        """Make models i and j compete once: return 1.0 if i wins and 0.0 otherwise."""
        if i == j:
            raise ValueError("A model cannot duel itself.")
        self.n_duels += 1
        return float(self.rng.random() < sigmoid(self.scores[i] - self.scores[j]))


def make_arena(n_models=8, rng=None):
    """Arena with scores drawn from a standard Gaussian distribution, in random order."""
    rng = np.random.default_rng(rng)
    return Arena(rng.normal(0, 1, n_models), rng)


def record(wins, i, j, i_wins):
    """Add the result of one duel to the matrix `wins`, where wins[i, j] counts the wins of i
    against j."""
    if i_wins:
        wins[i, j] += 1
    else:
        wins[j, i] += 1


def kendall_tau(x, y):
    """Kendall rank correlation between two score vectors: the proportion of concordant pairs
    minus the proportion of discordant pairs, in [-1, 1]."""
    x, y = np.asarray(x), np.asarray(y)
    i, j = np.triu_indices(len(x), k=1)
    return float(np.mean(np.sign(x[i] - x[j]) * np.sign(y[i] - y[j])))
