"""A character-level language model and simulated annotators, for RLHF and DPO (Lab 9).

The vocabulary has 27 tokens: the letters a to z (tokens 0 to 25) and the end of the word
(token 26). A word is generated letter by letter by a bigram model: the next token depends on
the previous letter only, or on the start of the word (row 26 of the tables). A bigram model
is given by a matrix of logits L of shape (27, 27): row p holds the logits of the next token
after the previous token p (p = 26 at the start), and the policy is softmax(L[p]).
"""

import re

import numpy as np

ALPHABET = "abcdefghijklmnopqrstuvwxyz"
END = 26  # token of the end of a word
START = 26  # row of the tables used for the first letter
MAX_LENGTH = 10

# Bigram counts of the 61171 words of 3 to 10 letters of the English word list of Debian
# (package wamerican): COUNTS[p, c] is the number of times token c follows p.
COUNTS = np.array([
    [44, 1210, 1971, 1523, 175, 366, 1141, 238, 1296, 45, 539, 3629, 1563, 5041, 52, 1073, 51, 4444, 2419, 4177, 752, 658, 455, 156, 757, 255, 1713],
    [1443, 405, 19, 34, 1525, 8, 4, 17, 927, 35, 2, 1392, 30, 26, 1158, 8, 1, 867, 317, 61, 831, 15, 11, 1, 137, 0, 169],
    [2361, 7, 265, 11, 1741, 3, 6, 2381, 1039, 0, 1623, 801, 10, 11, 2595, 7, 29, 1084, 228, 1007, 811, 4, 0, 0, 228, 9, 640],
    [944, 82, 43, 418, 3446, 45, 265, 66, 2307, 50, 5, 493, 91, 79, 1017, 37, 1, 601, 879, 36, 522, 61, 107, 0, 204, 9, 7057],
    [2348, 421, 1329, 6783, 1399, 627, 549, 165, 488, 55, 135, 2695, 1132, 4360, 323, 814, 133, 8922, 8819, 2097, 228, 658, 472, 677, 496, 111, 6272],
    [637, 12, 9, 5, 752, 625, 5, 4, 1081, 2, 3, 727, 6, 9, 790, 4, 0, 538, 134, 293, 623, 0, 4, 0, 151, 0, 201],
    [1056, 18, 2, 14, 1767, 16, 474, 584, 913, 4, 8, 655, 77, 301, 674, 19, 2, 917, 567, 50, 563, 1, 31, 0, 157, 9, 5492],
    [1858, 58, 17, 26, 2529, 28, 5, 19, 1628, 5, 12, 143, 105, 76, 1639, 16, 2, 342, 228, 372, 561, 2, 66, 0, 273, 3, 966],
    [1502, 482, 2418, 1244, 3245, 666, 1086, 22, 52, 26, 197, 2109, 1193, 10424, 1465, 651, 92, 1153, 3144, 2473, 161, 853, 22, 127, 10, 691, 517],
    [306, 0, 0, 0, 208, 1, 0, 0, 106, 0, 1, 0, 0, 0, 288, 1, 0, 1, 2, 0, 277, 0, 1, 0, 0, 0, 7],
    [330, 47, 9, 21, 1462, 28, 9, 85, 1017, 4, 31, 256, 29, 169, 155, 24, 0, 72, 603, 19, 92, 0, 47, 0, 159, 0, 768],
    [2969, 126, 139, 479, 4886, 146, 104, 29, 3835, 5, 195, 2477, 175, 49, 2114, 142, 1, 42, 1004, 517, 944, 173, 28, 12, 1730, 7, 1745],
    [2385, 688, 70, 11, 2134, 34, 2, 16, 1854, 0, 2, 59, 500, 99, 1372, 1046, 5, 22, 512, 12, 560, 4, 10, 0, 128, 1, 850],
    [1673, 137, 1370, 2164, 3384, 321, 6705, 141, 2065, 70, 578, 178, 69, 699, 1099, 81, 49, 99, 2232, 2831, 435, 214, 71, 24, 210, 62, 3427],
    [609, 542, 867, 819, 296, 308, 634, 101, 582, 26, 380, 1780, 1329, 4149, 1417, 940, 27, 3528, 1381, 1345, 2009, 711, 1070, 172, 244, 97, 777],
    [1537, 29, 25, 20, 2150, 19, 12, 563, 1367, 4, 17, 1004, 30, 26, 1317, 696, 0, 1323, 599, 412, 614, 1, 18, 0, 122, 1, 458],
    [4, 1, 0, 0, 0, 0, 0, 0, 7, 0, 0, 4, 0, 0, 1, 0, 0, 0, 1, 0, 862, 0, 1, 0, 0, 0, 8],
    [3800, 371, 488, 928, 5622, 170, 478, 112, 4061, 29, 426, 444, 666, 676, 2887, 272, 27, 806, 2626, 1316, 1060, 228, 93, 7, 723, 12, 3914],
    [1229, 90, 1113, 47, 2898, 56, 38, 2029, 1956, 9, 397, 626, 575, 283, 1069, 1093, 168, 40, 2047, 5100, 1056, 20, 323, 0, 253, 5, 17282],
    [2292, 90, 380, 26, 5506, 97, 33, 1626, 4257, 0, 11, 561, 83, 102, 1994, 51, 0, 1810, 1987, 1192, 950, 13, 204, 0, 672, 106, 3947],
    [575, 515, 637, 568, 672, 224, 466, 17, 619, 18, 79, 1403, 1046, 2158, 106, 555, 5, 1970, 2033, 1242, 11, 42, 7, 50, 27, 90, 153],
    [752, 1, 2, 5, 2260, 1, 2, 3, 1103, 0, 0, 11, 0, 2, 371, 2, 0, 7, 13, 3, 65, 17, 0, 0, 29, 0, 65],
    [1067, 50, 11, 71, 808, 20, 11, 316, 826, 0, 36, 136, 19, 269, 534, 23, 0, 167, 259, 23, 14, 0, 10, 0, 29, 6, 251],
    [77, 2, 99, 0, 220, 2, 2, 33, 225, 0, 0, 5, 3, 2, 49, 146, 1, 2, 2, 146, 37, 16, 6, 30, 27, 1, 200],
    [273, 81, 119, 70, 340, 28, 49, 29, 295, 6, 15, 159, 176, 161, 157, 179, 1, 135, 429, 75, 51, 5, 60, 12, 3, 19, 4160],
    [161, 6, 2, 3, 761, 0, 1, 16, 294, 0, 3, 76, 9, 5, 114, 5, 1, 2, 3, 6, 24, 3, 6, 0, 42, 181, 132],
    [3511, 3972, 5497, 3575, 2322, 2776, 2290, 2367, 1825, 806, 741, 2250, 3460, 1212, 1383, 4479, 293, 3348, 7334, 3185, 1175, 1015, 1833, 65, 276, 181, 0],])


def reference_logits():
    """Logits of the pretrained model: log of the bigram counts, smoothed by 1/2."""
    logits = np.log(COUNTS + 0.5)
    return logits - logits.max(axis=1, keepdims=True)


def softmax(logits):
    """Softmax of each row."""
    z = np.exp(logits - logits.max(axis=-1, keepdims=True))
    return z / z.sum(axis=-1, keepdims=True)


def sample(logits, n, rng=None):
    """Sample `n` words from the bigram model. Returns an integer array of shape
    (n, MAX_LENGTH + 1): the tokens of each word, ending with END, then padded with -1. A word
    is cut at MAX_LENGTH letters."""
    rng = np.random.default_rng(rng)
    cdf = softmax(logits).cumsum(axis=1)
    words = np.full((n, MAX_LENGTH + 1), -1)
    previous = np.full(n, START)
    alive = np.ones(n, dtype=bool)
    for t in range(MAX_LENGTH + 1):
        token = np.minimum((rng.random(n)[:, None] > cdf[previous]).sum(axis=1), END)
        if t == MAX_LENGTH:
            token[:] = END
        words[alive, t] = token[alive]
        alive &= token != END
        previous = np.where(alive, token, previous)
        if not alive.any():
            break
    return words


def encode(word):
    """Tokens of a string of letters, with the end token."""
    return np.array([ALPHABET.index(c) for c in word] + [END])


def decode(tokens):
    """String of the letters of a word given by its tokens."""
    return "".join(ALPHABET[t] for t in tokens if 0 <= t < END)


def transitions(tokens):
    """Matrix of shape (27, 27) counting the transitions (previous token, token) of a word:
    log pi(word) = sum of transitions(word) * log softmax(L)."""
    counts = np.zeros((27, 27))
    previous = START
    for t in tokens:
        if t < 0:
            break
        counts[previous, t] += 1
        if t == END:
            break
        previous = t
    return counts


def taste(word):
    """Score of a word (a string) for the annotators: soft letters (a, e, i, o, u, l, m, n)
    are liked, hard ones (j, k, q, v, x, z) disliked, runs of three vowels or three consonants
    are hard to pronounce, a pair of letters that comes back is a boring repetition, and the
    ideal length is 6. The learner never sees this function, only comparisons."""
    if not word:
        return -3.0
    soft = sum(c in "aeioulmn" for c in word) / len(word)
    hard = sum(c in "jkqvxz" for c in word)
    runs = len(re.findall(r"[^aeiou]{3,}|[aeiou]{3,}", word))
    pairs = [word[i:i + 2] for i in range(len(word) - 1)]
    repeats = len(pairs) - len(set(pairs))
    return 3 * soft - hard - 1.5 * runs - repeats - 0.3 * abs(len(word) - 6)


def compare(word_a, word_b, rng=None):
    """True if the annotators prefer word_a to word_b: Bradley-Terry model on taste."""
    rng = np.random.default_rng(rng)
    return bool(rng.random() < 1 / (1 + np.exp(taste(word_b) - taste(word_a))))


def preference_data(n, rng=None):
    """`n` comparisons of two words sampled from the reference model. Returns (chosen,
    rejected), two integer arrays of tokens of shape (n, MAX_LENGTH + 1)."""
    rng = np.random.default_rng(rng)
    a, b = sample(reference_logits(), n, rng), sample(reference_logits(), n, rng)
    first = np.array([compare(decode(x), decode(y), rng) for x, y in zip(a, b)])
    return np.where(first[:, None], a, b), np.where(first[:, None], b, a)


FEATURE_NAMES = list(ALPHABET) + ["length", "length^2/10"]


def word_features(word):
    """Features of a word (a string) for the reward model: the count of each letter, the
    length, and the squared length divided by 10."""
    features = np.zeros(len(FEATURE_NAMES))
    for c in word:
        features[ALPHABET.index(c)] += 1
    features[26], features[27] = len(word), len(word) ** 2 / 10
    return features
