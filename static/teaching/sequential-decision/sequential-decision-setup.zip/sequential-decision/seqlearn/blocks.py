"""Falling blocks: a small stacking game for approximate Q-learning (Lab 8)."""

import matplotlib.pyplot as plt
import numpy as np

from .plotting import COLORS, MUTED, TEXT

# Default pieces, drawn row by row from the top with '#' for a filled cell. Any list of such
# drawings can be passed to Blocks(pieces=...).
PIECES = [
    ["#"],
    ["##"],
    ["###"],
    ["#.",
     "##"],
]


def _cells(drawing):
    """Cells (row from the bottom, column) of a drawing."""
    height = len(drawing)
    return [(height - 1 - i, j) for i, row in enumerate(drawing) for j, c in enumerate(row) if c == "#"]


def _normalize(cells):
    r0, c0 = min(r for r, _ in cells), min(c for _, c in cells)
    return tuple(sorted((r - r0, c - c0) for r, c in cells))


def _rotations(drawing):
    """Distinct rotations of a piece, each as a sorted tuple of cells."""
    shapes, cells = [], _normalize(_cells(drawing))
    for _ in range(4):
        if cells not in shapes:
            shapes.append(cells)
        cells = _normalize([(c, -r) for r, c in cells])  # quarter turn
    return shapes


class Blocks:
    """Pieces fall one at a time in a well of `width` columns and `height` rows.

    The state is (board, piece): `board` is a boolean array of shape (height, width), row 0 at
    the bottom, and `piece` the index of the falling piece in `pieces`. An action is a
    placement (rotation, column): the piece is turned, moved to the column and dropped
    straight down. Each full row is removed and gives a reward 1. The game ends when a
    piece sticks out of the top of the well, with a reward `lose`, or after `max_pieces`
    pieces. `rows` counts the rows removed since the start of the game.
    """

    def __init__(self, width=6, height=10, pieces=PIECES, max_pieces=500, lose=-1.0, rng=None):
        self.width, self.height, self.max_pieces, self.lose = width, height, max_pieces, lose
        self.pieces = [_rotations(p) for p in pieces]
        # Placements of each piece: (rotation, leftmost column) inside the well
        self.placements = [[(k, c) for k, shape in enumerate(rotations)
                            for c in range(width - max(j for _, j in shape))]
                           for rotations in self.pieces]
        self.rng = np.random.default_rng(rng)

    def reset(self):
        self.board = np.zeros((self.height, self.width), dtype=bool)
        self.piece = int(self.rng.integers(len(self.pieces)))
        self.count = self.rows = 0
        return self.board.copy(), self.piece

    def actions(self, piece=None):
        """Legal placements (rotation, column) of `piece` (by default the falling one)."""
        return self.placements[self.piece if piece is None else piece]

    def drop(self, board, piece, action):
        """Board after dropping `piece` with `action`, before removing full rows, or None if the
        piece sticks out of the top. Does not change the game."""
        shape = self.pieces[piece][action[0]]
        column = action[1]
        filled = board.any(axis=0)
        tops = np.where(filled, self.height - np.argmax(board[::-1], axis=0), 0)
        bottom = {}
        for r, j in shape:
            bottom[j] = min(r, bottom.get(j, r))
        row = max(tops[column + j] - r for j, r in bottom.items())
        if row + max(r for r, _ in shape) >= self.height:
            return None
        new = board.copy()
        for r, j in shape:
            new[row + r, column + j] = True
        return new

    @staticmethod
    def clear(board):
        """Board after removing its full rows, and the number of rows removed."""
        full = board.all(axis=1)
        kept = board[~full]
        cleared = int(full.sum())
        return np.vstack([kept, np.zeros((cleared, board.shape[1]), dtype=bool)]), cleared

    def step(self, action):
        """Play the placement `action`: return ((board, piece), reward, done)."""
        dropped = self.drop(self.board, self.piece, action)
        self.count += 1
        if dropped is None:
            return (self.board.copy(), self.piece), self.lose, True
        self.board, cleared = self.clear(dropped)
        self.rows += cleared
        self.piece = int(self.rng.integers(len(self.pieces)))
        return (self.board.copy(), self.piece), float(cleared), self.count >= self.max_pieces

    def draw(self, ax, board=None, piece=None, title=None):
        """Draw a board (by default the current one) and, next to it, the falling piece."""
        board = self.board if board is None else board
        ax.add_patch(plt.Rectangle((-0.5, -0.5), self.width, self.height, fill=False, ec=MUTED, lw=1.5))
        for r, j in zip(*np.nonzero(board)):
            ax.add_patch(plt.Rectangle((j - 0.45, r - 0.45), 0.9, 0.9, color=COLORS[0]))
        if piece is not None:
            for r, j in self.pieces[piece][0]:
                ax.add_patch(plt.Rectangle((self.width + 0.55 + j, self.height - 3.45 + r), 0.9, 0.9,
                                           color=COLORS[1]))
            ax.text(self.width + 0.5, self.height - 0.8, "piece", color=TEXT, fontsize="small")
        ax.set_xlim(-0.7, self.width + (3.8 if piece is not None else 0.2))
        ax.set_ylim(-0.7, self.height - 0.3)
        ax.set_aspect("equal")
        ax.set_xticks([])
        ax.set_yticks([])
        ax.grid(False)
        for spine in ax.spines.values():
            spine.set_visible(False)
        if title:
            ax.set_title(title, color=TEXT)


def board_features(boards):
    """Features of a board, or of each board of a stack of shape (n, height, width): column
    heights, number of holes (empty cells below a filled one), bumpiness (sum of the height
    differences of neighboring columns) and maximal height."""
    boards = np.asarray(boards, dtype=bool)
    height = boards.shape[-2]
    tops = np.where(boards.any(axis=-2), height - np.argmax(boards[..., ::-1, :], axis=-2), 0)
    holes = tops.sum(axis=-1) - boards.sum(axis=(-2, -1))
    bumpiness = np.abs(np.diff(tops, axis=-1)).sum(axis=-1)
    return np.concatenate([tops, holes[..., None], bumpiness[..., None], tops.max(axis=-1, keepdims=True)],
                          axis=-1).astype(float)


def placement_features(env, board, piece):
    """Features phi(s, a) of all the legal placements a of `piece` on `board`.

    Returns (actions, phi, rewards, lost): the list of the placements, the array phi of shape
    (n_placements, 11) whose rows are a constant 1, the features of the board obtained (after
    removing the full rows) divided by the height of the well, and the number of rows
    removed; the rewards; and a boolean array, True for the placements that end the game
    (their row of phi is zero, their reward is env.lose)."""
    actions = env.actions(piece)
    n = len(actions)
    boards = np.zeros((n, env.height, env.width), dtype=bool)
    lost = np.zeros(n, dtype=bool)
    for k, action in enumerate(actions):
        dropped = env.drop(board, piece, action)
        if dropped is None:
            lost[k] = True
        else:
            boards[k] = dropped
    full = boards.all(axis=2)
    cleared = full.sum(axis=1)
    for k in np.nonzero(cleared)[0]:
        boards[k] = env.clear(boards[k])[0]
    phi = np.concatenate([np.ones((n, 1)), board_features(boards) / env.height, cleared[:, None]], axis=1)
    phi[lost] = 0.0
    rewards = np.where(lost, env.lose, cleared.astype(float))
    return actions, phi, rewards, lost
