"""Off-policy evaluation on the recommendation problem with user profiles (Lab 5).

At each round a user arrives with a profile, a probability vector over N_MOODS moods, and
item a is clicked with probability <profile, APPEAL[a]>. A policy is a function that maps
an array of profiles, of shape (n, N_MOODS), to the array of the probabilities of the
items, of shape (n, N_ITEMS): row i is the distribution of the item recommended to user i.
"""

import numpy as np

APPEAL = np.array([[0.8, 0.2, 0.3, 0.1],
                   [0.2, 0.8, 0.2, 0.3],
                   [0.3, 0.2, 0.8, 0.2],
                   [0.1, 0.3, 0.2, 0.8],
                   [0.5, 0.5, 0.5, 0.5]])
N_ITEMS, N_MOODS = APPEAL.shape
CONCENTRATION = 0.3

# Click rates estimated by the recommender currently in production: noisy, and biased
# towards the last item.
_OLD_APPEAL = APPEAL + np.random.default_rng(1).normal(0, 0.15, APPEAL.shape)
_OLD_APPEAL[-1] += 0.2


def draw_profiles(n, rng=None):
    """Profiles of `n` users, of shape (n, N_MOODS)."""
    return np.random.default_rng(rng).dirichlet(CONCENTRATION * np.ones(N_MOODS), size=n)


def click_probabilities(profiles):
    """Click probability of each item for each user, of shape (n, N_ITEMS)."""
    return profiles @ APPEAL.T


def softmax(scores, temperature=1.0):
    """Softmax of each row of `scores`."""
    z = np.asarray(scores, dtype=float) / temperature
    z = np.exp(z - z.max(axis=-1, keepdims=True))
    return z / z.sum(axis=-1, keepdims=True)


def old_recommender(profiles):
    """Policy in production: softmax of its estimated click rates, temperature 0.1."""
    return softmax(profiles @ _OLD_APPEAL.T, temperature=0.1)


def uniform_policy(profiles):
    return np.full((len(profiles), N_ITEMS), 1 / N_ITEMS)


def constant_policy(item):
    """Policy that always recommends `item`."""
    def policy(profiles):
        probs = np.zeros((len(profiles), N_ITEMS))
        probs[:, item] = 1.0
        return probs
    return policy


def collect_logs(policy, n, rng=None):
    """Let `policy` recommend to `n` users and record what happens.

    Return a dictionary of arrays of length n: "profiles" (shape (n, N_MOODS)), "items" (the
    recommended items), "clicks" (0 or 1) and "propensities" (the probability with which the
    policy chose the recommended item).
    """
    rng = np.random.default_rng(rng)
    profiles = draw_profiles(n, rng)
    probs = policy(profiles)
    items = (probs.cumsum(axis=1) < rng.random((n, 1))).sum(axis=1).clip(max=N_ITEMS - 1)
    rows = np.arange(n)
    clicks = (rng.random(n) < click_probabilities(profiles)[rows, items]).astype(float)
    return {"profiles": profiles, "items": items, "clicks": clicks, "propensities": probs[rows, items]}


def true_value(policy, n=200_000, rng=12345):
    """Click rate of `policy`, by exact averaging over the items on `n` simulated users."""
    profiles = draw_profiles(n, rng)
    return float(np.mean(np.sum(policy(profiles) * click_probabilities(profiles), axis=1)))
