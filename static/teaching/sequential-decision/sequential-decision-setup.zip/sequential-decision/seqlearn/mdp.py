"""Finite Markov decision processes and grid worlds (Lab 7)."""

import matplotlib.pyplot as plt
import numpy as np

from .plotting import MUTED, TEXT

# Actions of the grid worlds, as (row, column) moves.
ACTIONS = ["up", "right", "down", "left"]
MOVES = [(-1, 0), (0, 1), (1, 0), (0, -1)]


class TabularMDP:
    """Finite MDP given by its transition probabilities and expected rewards.

    P[s, a, s'] is the probability of moving to s' when playing a in s, and R[s, a] the
    expected reward of this step. Terminal states are absorbing, with reward zero. `reset`
    and `step` simulate the MDP, for algorithms that do not use P and R.
    """

    def __init__(self, P, R, start, terminal=(), rng=None):
        self.P = np.asarray(P, dtype=float)
        self.R = np.asarray(R, dtype=float)
        self.n_states, self.n_actions = self.R.shape
        self.start = start
        self.terminal = np.zeros(self.n_states, dtype=bool)
        self.terminal[list(terminal)] = True
        self.rng = np.random.default_rng(rng)
        self._rewards = {}  # (s, a, s') -> reward, when it depends on s'
        self.state = start

    def reset(self):
        self.state = self.start
        return self.state

    def step(self, action):
        """Play `action` in the current state: return (next state, reward, done)."""
        s = self.state
        s_next = int(self.rng.choice(self.n_states, p=self.P[s, action]))
        reward = self._rewards.get((s, action, s_next), self.R[s, action])
        self.state = s_next
        return s_next, reward, bool(self.terminal[s_next])


class GridWorld(TabularMDP):
    """Grid world built from a list of strings, one per row.

    Cells: '.' free, '#' wall, 'S' start, 'G' goal (reward `goal`, terminal), 'T' trap
    (reward `trap`, terminal), 'g' small goal (reward `small_goal`, terminal), 'C' cliff
    (reward `cliff` and back to the start). Every move costs `step`. With probability
    `slip`, the move goes in a uniformly random direction instead. Moving into a wall or
    out of the grid leaves the agent in place.
    """

    def __init__(self, layout, step=0.0, goal=1.0, trap=-1.0, small_goal=0.1, cliff=-100.0, slip=0.0,
                 rng=None):
        self.layout = [list(row) for row in layout]
        self.n_rows, self.n_cols = len(layout), len(layout[0])
        self.cells = [(i, j) for i in range(self.n_rows) for j in range(self.n_cols) if layout[i][j] != "#"]
        index = {cell: k for k, cell in enumerate(self.cells)}
        self.index = index
        n = len(self.cells)
        start = next(index[c] for c in self.cells if self.kind(c) == "S")
        exit_reward = {"G": goal, "T": trap, "g": small_goal}
        terminal = [index[c] for c in self.cells if self.kind(c) in exit_reward]
        P = np.zeros((n, 4, n))
        R = np.zeros((n, 4))
        rewards = {}
        for c in self.cells:
            s = index[c]
            if s in terminal:
                P[s, :, s] = 1.0
                continue
            for a in range(4):
                outcomes = [(1 - slip, a)] + [(slip / 4, b) for b in range(4)]
                for prob, b in outcomes:
                    if prob == 0:
                        continue
                    target = (c[0] + MOVES[b][0], c[1] + MOVES[b][1])
                    if target not in index:
                        target = c
                    r = step
                    kind = self.kind(target)
                    if kind == "C":
                        r, target = step + cliff, self.cells[start]
                    elif kind in exit_reward:
                        r = step + exit_reward[kind]
                    t = index[target]
                    P[s, a, t] += prob
                    R[s, a] += prob * r
                    rewards[(s, a, t)] = r
        super().__init__(P, R, start, terminal, rng)
        self._rewards = rewards

    def kind(self, cell):
        return self.layout[cell[0]][cell[1]]

    def plot(self, ax, values=None, policy=None, title=None):
        """Draw the grid, with `values` (one per state) as colors and `policy` (one action per
        state) as arrows."""
        grid = np.full((self.n_rows, self.n_cols), np.nan)
        if values is not None:
            for k, c in enumerate(self.cells):
                grid[c] = values[k]
            image = ax.imshow(grid, cmap="Blues")
            plt.colorbar(image, ax=ax, fraction=0.035)
        for i in range(self.n_rows):
            for j in range(self.n_cols):
                kind = self.layout[i][j]
                if kind == "#":
                    ax.add_patch(plt.Rectangle((j - 0.5, i - 0.5), 1, 1, color=TEXT))
                elif kind == "C":
                    ax.add_patch(plt.Rectangle((j - 0.5, i - 0.5), 1, 1, color="#e34948", alpha=0.6))
                if kind in "SGTgC":
                    ax.text(j, i, kind, ha="center", va="center", fontsize=10, fontweight="bold", color=TEXT)
        if policy is not None:
            for k, c in enumerate(self.cells):
                if self.terminal[k] or self.kind(c) == "C":
                    continue
                di, dj = MOVES[int(policy[k])]
                ax.annotate("", xy=(c[1] + 0.3 * dj, c[0] + 0.3 * di), xytext=(c[1] - 0.3 * dj, c[0] - 0.3 * di),
                            arrowprops=dict(arrowstyle="->", color="black", lw=1.2))
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_xlim(-0.5, self.n_cols - 0.5)
        ax.set_ylim(self.n_rows - 0.5, -0.5)
        for spine in ax.spines.values():
            spine.set_color(MUTED)
        if title:
            ax.set_title(title)


MAZE = [
    "S...#....",
    ".##.#.##.",
    ".#.....#.",
    ".#.##T.#.",
    "...#...#G",
]

CHOICE = [
    "..........",
    ".g.......G",
    "..........",
    "S.........",
]

CLIFF = [
    "............",
    "............",
    "............",
    "SCCCCCCCCCCG",
]


def make_maze(slip=0.1, rng=None):
    """Maze of Lab 7: goal G (+1) and trap T (-1), slippery moves."""
    return GridWorld(MAZE, step=0.0, goal=1.0, trap=-1.0, slip=slip, rng=rng)


def make_choice(rng=None):
    """A small reward g (0.1) close to the start and a large one G (1) far away."""
    return GridWorld(CHOICE, step=0.0, goal=1.0, small_goal=0.1, rng=rng)


def make_cliff(rng=None):
    """Cliff walking (Sutton and Barto, example 6.6): -1 per move, -100 and back to the start
    when falling from the cliff C, episode ends at G."""
    return GridWorld(CLIFF, step=-1.0, goal=0.0, cliff=-100.0, rng=rng)
