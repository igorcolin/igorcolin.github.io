"""Bandit challenge (Lab 4): three tracks, one agent, a score relative to UCB1.

An agent is built by a function `make_agent(n_arms, dim, horizon, rng)` and follows the
interface of `LinearAgent`: `act(features)` returns the arm to play and
`update(x, arm, reward)` receives the result. The three tracks are linear bandits with
Bernoulli rewards:

  slots    K = 20 arms with small means (click rates), features e_1, ..., e_K
  catalog  K = 300 items described by d = 8 features, the same at every round
  users    K = 6 items and a user profile over 4 moods at each round, d = 24

The score of a track is the mean final pseudo-regret of the agent divided by the one of
UCB1, which ignores the features, on the same instances, in percent. The score of the
challenge is the mean of the three track scores: the lower, the better.
"""

import importlib.util
import time
from pathlib import Path

import numpy as np

from .agents import UCBAgent
from .linear import CatalogBandit, ContextFree, RecommendationBandit, make_catalog, run_linear

HORIZON = 5000
TRACKS = ("slots", "catalog", "users")


def make_env(track, rng):
    """Draw an instance of `track` (its parameters and its randomness) from `rng`."""
    rng = np.random.default_rng(rng)
    if track == "slots":
        n_arms = 20
        return CatalogBandit(np.eye(n_arms), rng.beta(1.5, 12, size=n_arms), rng)
    if track == "catalog":
        items, theta = make_catalog(300, 8, rng)
        return CatalogBandit(items, theta, rng)
    if track == "users":
        return RecommendationBandit(rng.beta(0.7, 2.0, size=(6, 4)), concentration=0.3, rng=rng)
    raise ValueError(f"unknown track {track!r}, expected one of {TRACKS}")


def make_reference(n_arms, dim, horizon, rng):
    """UCB1 on unrelated arms, the reference of the scores."""
    return ContextFree(UCBAgent(n_arms, 2.0, rng))


def final_regrets(make_agent, track, n_runs, seed):
    """Final pseudo-regret of `n_runs` runs on `track`, on instances derived from `seed`."""
    regrets = np.empty(n_runs)
    for i, child in enumerate(np.random.SeedSequence([seed, TRACKS.index(track)]).spawn(n_runs)):
        env_seed, agent_seed = child.spawn(2)
        env = make_env(track, np.random.default_rng(env_seed))
        dim = env.features().shape[1]
        agent = make_agent(env.n_arms, dim, HORIZON, np.random.default_rng(agent_seed))
        regrets[i] = run_linear(env, agent, HORIZON)[2].sum()
    return regrets


def evaluate(make_agent, n_runs=10, seed=0, verbose=True):
    """Evaluate an agent on the three tracks, against the reference.

    Return a dictionary: for each track, the mean final regret of the agent and of the
    reference, and the score; and the overall score under the key "score".
    """
    results = {}
    for track in TRACKS:
        start = time.perf_counter()
        agent = final_regrets(make_agent, track, n_runs, seed)
        elapsed = time.perf_counter() - start
        reference = final_regrets(make_reference, track, n_runs, seed)
        score = 100 * agent.mean() / reference.mean()
        results[track] = {"regret": agent.mean(), "reference": reference.mean(), "score": score,
                          "seconds": elapsed}
        if verbose:
            print(f"{track:8s} regret {agent.mean():7.1f} (UCB1 {reference.mean():6.1f})"
                  f"  score {score:5.1f}  [{elapsed:.0f} s]")
    results["score"] = float(np.mean([results[track]["score"] for track in TRACKS]))
    if verbose:
        print(f"score of the challenge: {results['score']:.1f} (UCB1: 100, lower is better)")
    return results


def load_agent(path):
    """Load the function `make_agent` of the file `path`, reloading the file at each call."""
    path = Path(path)
    spec = importlib.util.spec_from_file_location(f"challenge_{path.stem}", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.make_agent
