"""Automatic tests for the labs. Each function raises AssertionError with an explicit message."""

import numpy as np

from .bandits import Bandit, run


class _FixedBandit(Bandit):
    """Deterministic bandit: arm a always pays means[a]."""

    def pull(self, arm):
        return float(self.means[arm])


class _DecayBandit(Bandit):
    """Arm 0 pays 1 at its first pull and 0 afterwards; arm 1 always pays 0.5."""

    def __init__(self):
        super().__init__([0.0, 0.5])
        self._first = True

    def pull(self, arm):
        if arm == 1:
            return 0.5
        reward, self._first = float(self._first), False
        return reward


def _arms(agent, env, horizon):
    arms, _ = run(env, agent, horizon)
    return arms.tolist()


def _ok(name):
    print(f"{name}: all tests passed.")


def check_pseudo_regret(pseudo_regret):
    gaps = np.array([0.0, 0.1, 0.3])
    arms = np.array([0, 1, 1, 2])
    expected = np.array([0.0, 0.1, 0.2, 0.5])
    out = pseudo_regret(arms, gaps)
    assert out is not None, "pseudo_regret returns nothing."
    assert np.allclose(out, expected), (
        f"For arms={arms.tolist()} and gaps={gaps.tolist()}, "
        f"expected {expected.tolist()}, got {np.asarray(out).tolist()}."
    )
    batch = np.stack([arms, arms[::-1]])
    out = pseudo_regret(batch, gaps)
    assert np.shape(out) == (2, 4), "For arms of shape (n_runs, T), the output must have the same shape."
    assert np.allclose(out, [expected, [0.3, 0.4, 0.5, 0.5]]), (
        "The cumulative sum must run along the last axis (time)."
    )
    _ok("pseudo_regret")


def check_greedy(GreedyAgent):
    got = _arms(GreedyAgent(3), _FixedBandit([0.2, 0.8, 0.5]), 6)
    assert got == [0, 1, 2, 1, 1, 1], (
        f"Noiseless means (0.2, 0.8, 0.5): expected [0, 1, 2, 1, 1, 1], got {got}. "
        "Each arm must be pulled once, in order, before taking the argmax."
    )
    got = _arms(GreedyAgent(2), _FixedBandit([0.5, 0.5]), 4)
    assert got == [0, 1, 0, 0], (
        f"Equal means: expected [0, 1, 0, 0], got {got}. Ties must go to the smallest index."
    )
    agent = GreedyAgent(2)
    _arms(agent, _FixedBandit([0.9, 0.1]), 5)
    got = _arms(agent, _FixedBandit([0.1, 0.9]), 4)
    assert got == [0, 1, 1, 1], "reset() must bring the agent back to its initial state."
    _ok("GreedyAgent")


def check_epsilon_greedy(EpsilonGreedyAgent):
    got = _arms(EpsilonGreedyAgent(3, 0.0), _FixedBandit([0.2, 0.8, 0.5]), 6)
    assert got == [0, 1, 2, 1, 1, 1], f"With epsilon = 0, the agent must behave like greedy: got {got}."
    horizon = 4002
    arms = np.array(_arms(EpsilonGreedyAgent(3, 1.0, rng=0), _FixedBandit([0.2, 0.8, 0.5]), horizon))
    freqs = np.bincount(arms[3:], minlength=3) / (horizon - 3)
    assert np.allclose(freqs, 1 / 3, atol=0.04), (
        f"With epsilon = 1, arms must be uniform: frequencies {freqs.round(3)}."
    )
    arms = np.array(_arms(EpsilonGreedyAgent(2, 0.3, rng=0), _FixedBandit([0.0, 1.0]), horizon))
    freq = np.mean(arms[2:] == 0)
    assert abs(freq - 0.15) < 0.03, (
        "With epsilon = 0.3 and two arms, the bad arm must be played about 15% of the time "
        f"(uniform exploration, hence epsilon / 2): got {100 * freq:.1f}%."
    )
    _ok("EpsilonGreedyAgent")


def check_etc(ETCAgent):
    got = _arms(ETCAgent(3, 2), _FixedBandit([0.3, 0.7, 0.5]), 9)
    assert got == [0, 1, 2, 0, 1, 2, 1, 1, 1], (
        f"ETC(m=2) on (0.3, 0.7, 0.5): expected [0, 1, 2, 0, 1, 2, 1, 1, 1], got {got}. "
        "During exploration, arms are played in turn."
    )
    got = _arms(ETCAgent(2, 3), _FixedBandit([0.5, 0.5]), 8)
    assert got == [0, 1, 0, 1, 0, 1, 0, 0], (
        f"Equal means: expected [0, 1, 0, 1, 0, 1, 0, 0], got {got}. Ties must go to the smallest index."
    )
    got = _arms(ETCAgent(2, 1), _DecayBandit(), 6)
    assert got == [0, 1, 0, 0, 0, 0], (
        f"Expected [0, 1, 0, 0, 0, 0], got {got}. After exploration, ETC plays the same arm "
        "until the end, even if the empirical means change."
    )
    _ok("ETCAgent")


# ---------------------------------------------------------------------------
# Lab 2

def check_ucb(UCBAgent):
    agent = UCBAgent(2, alpha=2.0)
    for arm, reward in [(0, 1.0), (1, 0.0), (0, 0.0)]:
        agent.update(arm, reward)
    out = agent.index()
    assert out is not None, "index returns nothing."
    assert np.shape(out) == (2,), f"index must return an array of length n_arms: got shape {np.shape(out)}."
    expected = np.array([0.5, 0.0]) + np.sqrt(2.0 * np.log(4) / np.array([2, 1]))
    shifted = np.array([0.5, 0.0]) + np.sqrt(2.0 * np.log(3) / np.array([2, 1]))
    assert not np.allclose(out, shifted), (
        "After 3 rounds, the index is the one of round t = 4: the logarithm is log(self.t + 1), "
        "not log(self.t)."
    )
    assert not np.allclose(out, [0.5, 0.0]), "The index is the empirical mean alone: the bonus is missing."
    assert np.allclose(out, expected), (
        f"After the pulls (arm 0, reward 1), (arm 1, reward 0), (arm 0, reward 0), with alpha = 2, "
        f"expected {expected.round(3).tolist()}, got {np.asarray(out).round(3).tolist()}."
    )
    agent = UCBAgent(2, alpha=0.5)
    for arm, reward in [(0, 1.0), (1, 0.0), (0, 0.0)]:
        agent.update(arm, reward)
    expected = np.array([0.5, 0.0]) + np.sqrt(0.5 * np.log(4) / np.array([2, 1]))
    assert np.allclose(agent.index(), expected), (
        f"With alpha = 0.5, expected {expected.round(3).tolist()}, "
        f"got {np.asarray(agent.index()).round(3).tolist()}. The bonus must depend on self.alpha."
    )
    got = _arms(UCBAgent(3, alpha=2.0), _FixedBandit([0.2, 0.8, 0.5]), 3)
    assert got == [0, 1, 2], f"During the first K rounds, each arm must be pulled once, in order: got {got}."
    got = _arms(UCBAgent(3, alpha=2.0), _FixedBandit([0.2, 0.8, 0.5]), 12)
    expected = [0, 1, 2, 1, 2, 1, 0, 1, 2, 1, 1, 2]
    assert got == expected, (
        f"Noiseless means (0.2, 0.8, 0.5), alpha = 2: expected {expected}, got {got}. "
        "After the first K rounds, play the argmax of the index."
    )
    got = _arms(UCBAgent(2, alpha=0.5), _FixedBandit([0.9, 0.1]), 14)
    expected = [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]
    assert got == expected, f"Noiseless means (0.9, 0.1), alpha = 0.5: expected {expected}, got {got}."
    agent = UCBAgent(2, alpha=2.0)
    _arms(agent, _FixedBandit([0.9, 0.1]), 5)
    got = _arms(agent, _FixedBandit([0.1, 0.9]), 4)
    assert got == [0, 1, 1, 1], "reset() must bring the agent back to its initial state."
    _ok("UCBAgent")


# ---------------------------------------------------------------------------
# Lab 3

def _feed(agent, history):
    for arm, reward in history:
        agent.update(arm, reward)


def check_thompson(ThompsonAgent):
    agent = ThompsonAgent(2, rng=0)
    _feed(agent, [(0, 1.0), (0, 1.0), (0, 0.0), (1, 0.0)])
    out = agent.posterior()
    assert out is not None and len(out) == 2, "posterior must return the pair (alpha, beta)."
    alpha, beta = np.asarray(out[0], dtype=float), np.asarray(out[1], dtype=float)
    assert alpha.shape == (2,) and beta.shape == (2,), "alpha and beta must be arrays of length n_arms."
    assert np.allclose(alpha, [3, 1]) and np.allclose(beta, [2, 2]), (
        "After 2 successes and 1 failure on arm 0, and 1 failure on arm 1, with uniform priors, "
        f"expected alpha = [3, 1] and beta = [2, 2], got alpha = {alpha.tolist()} and beta = {beta.tolist()}."
    )
    agent = ThompsonAgent(3, rng=0)
    draws = np.array([agent.act() for _ in range(3000)])
    assert np.all(np.isin(draws, [0, 1, 2])), "act() must return an arm index."
    freqs = np.bincount(draws, minlength=3) / len(draws)
    assert np.allclose(freqs, 1 / 3, atol=0.04), (
        f"Before any observation, the three arms must be played with the same probability: frequencies {freqs.round(3)}. "
        "Thompson sampling has no initialization rounds."
    )
    agent = ThompsonAgent(2, rng=0)
    _feed(agent, [(0, 1.0)] * 60 + [(1, 0.0)] * 60)
    draws = [agent.act() for _ in range(200)]
    assert all(arm == 0 for arm in draws), "After 60 successes on arm 0 and 60 failures on arm 1, arm 0 must always be played."
    agent = ThompsonAgent(2, rng=0)
    _feed(agent, [(0, 1.0), (1, 0.0)])
    freq = np.mean([agent.act() == 0 for _ in range(6000)])
    assert abs(freq - 5 / 6) < 0.02, (
        "After one success on arm 0 and one failure on arm 1, arm 0 must be played with probability 5/6 "
        f"(Tutorial 3, exercise 1): got {freq:.3f}."
    )
    first, second = ThompsonAgent(2, rng=7), ThompsonAgent(2, rng=7)
    assert [first.act() for _ in range(50)] == [second.act() for _ in range(50)], (
        "Two agents with the same seed must make the same choices: use self.rng for all random draws."
    )
    _ok("ThompsonAgent")


def _ridge_data():
    rng = np.random.default_rng(0)
    xs = rng.standard_normal((6, 3))
    rs = rng.random(6)
    lam = 2.0
    V = lam * np.eye(3) + xs.T @ xs
    b = xs.T @ rs
    return xs, rs, lam, V, b


def check_ridge(Ridge):
    xs, rs, lam, V, b = _ridge_data()
    ridge = Ridge(3, lam)
    assert np.allclose(ridge.V_inv, np.eye(3) / lam), "Before any observation, V_inv must be the identity divided by lam."
    assert np.allclose(ridge.theta_hat, 0), "Before any observation, theta_hat must be zero."
    for x, r in zip(xs, rs):
        ridge.update(x, r)
    assert np.allclose(ridge.V_inv, np.linalg.inv(V)), (
        "After 6 updates, V_inv differs from the inverse of lam * I + sum of x x^T: check the Sherman-Morrison update."
    )
    assert np.allclose(ridge.b, b), "After 6 updates, b must be the sum of the r x."
    assert np.allclose(ridge.theta_hat, np.linalg.solve(V, b)), "theta_hat must be V_inv @ b, recomputed after each update."
    X = np.array([[1.0, 0.0, 0.0], [0.0, 2.0, 0.0], [1.0, 1.0, 1.0], [0.5, -1.0, 2.0]])
    out = ridge.width(X)
    assert out is not None, "width returns nothing."
    expected = np.sqrt(np.sum(X @ np.linalg.inv(V) * X, axis=1))
    assert np.shape(out) == (4,), f"For features of shape (4, 3), width must return an array of length 4: got shape {np.shape(out)}."
    assert np.allclose(out, expected), (
        f"width must return sqrt(x^T V_inv x) for each row x: expected {expected.round(3).tolist()}, got {np.asarray(out).round(3).tolist()}."
    )
    _ok("Ridge")


_LIN_HISTORY = [([1.0, 0.0], 1.0), ([1.0, 0.0], 1.0), ([1.0, 0.0], 0.0), ([1.0, 0.0], 0.0), ([0.0, 1.0], 0.0)]
_LIN_FEATURES = np.array([[1.0, 0.0], [0.0, 1.0], [1.0, 1.0]])


def _feed_linear(agent):
    for x, reward in _LIN_HISTORY:
        agent.update(np.array(x), 0, reward)


def check_linucb(LinUCBAgent):
    agent = LinUCBAgent(2, beta=1.0, lam=1.0)
    out = agent.index(np.array([[1.0, 0.0], [2.0, 0.0]]))
    assert out is not None, "index returns nothing."
    assert np.allclose(out, [1.0, 2.0]), (
        f"Before any observation, with beta = 1 and lam = 1, the index of x is its norm: expected [1, 2], got {np.asarray(out).round(3).tolist()}."
    )
    _feed_linear(agent)
    out = np.asarray(agent.index(_LIN_FEATURES))
    expected = np.array([0.4 + np.sqrt(0.2), np.sqrt(0.5), 0.4 + np.sqrt(0.7)])
    assert np.allclose(out, expected), (
        "Example of Tutorial 3 (exercise 3): V = diag(5, 2), theta_hat = (0.4, 0), beta = 1. "
        f"Expected indices {expected.round(3).tolist()}, got {out.round(3).tolist()}."
    )
    assert agent.act(_LIN_FEATURES) == 2, "On the example of Tutorial 3, LinUCB must play the third arm."
    assert isinstance(agent.act(_LIN_FEATURES), (int, np.integer)), "act() must return an integer."
    agent = LinUCBAgent(2, beta=0.0, lam=1.0)
    _feed_linear(agent)
    assert agent.act(_LIN_FEATURES) == 0, "With beta = 0, the agent plays the argmax of <theta_hat, x>, ties going to the smallest index."
    agent.reset()
    assert np.allclose(agent.index(np.array([[1.0, 0.0]])), 0.0), "reset() must forget the observations."
    _ok("LinUCBAgent")


def check_lints(LinTSAgent):
    agent = LinTSAgent(2, v=0.5, lam=1.0, rng=0)
    _feed_linear(agent)
    samples = np.array([agent.sample() for _ in range(6000)])
    assert samples.shape == (6000, 2), "sample() must return a vector of length dim."
    mean, cov = samples.mean(axis=0), np.cov(samples.T)
    assert np.allclose(mean, [0.4, 0.0], atol=0.02), (
        f"The samples must be centered at theta_hat = (0.4, 0): empirical mean {mean.round(3).tolist()}."
    )
    expected = 0.25 * np.diag([0.2, 0.5])
    assert np.allclose(cov, expected, atol=0.01), (
        "The covariance of the samples must be v^2 V_inv = diag(0.05, 0.125): "
        f"empirical covariance {cov.round(3).tolist()}."
    )
    agent = LinTSAgent(2, v=0.0, lam=1.0, rng=0)
    _feed_linear(agent)
    assert all(agent.act(_LIN_FEATURES[:2]) == 0 for _ in range(20)), "With v = 0, the agent plays the argmax of <theta_hat, x>."
    first, second = LinTSAgent(2, v=1.0, lam=1.0, rng=3), LinTSAgent(2, v=1.0, lam=1.0, rng=3)
    assert [first.act(_LIN_FEATURES) for _ in range(30)] == [second.act(_LIN_FEATURES) for _ in range(30)], (
        "Two agents with the same seed must make the same choices: use self.rng for all random draws."
    )
    _ok("LinTSAgent")


# ---------------------------------------------------------------------------
# Lab 0

def check_gaps(gaps):
    out = gaps(np.array([0.5, 0.6, 0.4]))
    assert out is not None, "gaps returns nothing."
    assert np.allclose(out, [0.1, 0.0, 0.2]), (
        f"For means (0.5, 0.6, 0.4), expected [0.1, 0.0, 0.2], got {np.asarray(out).tolist()}."
    )
    _ok("gaps")


def check_counts(counts):
    out = counts(np.array([0, 2, 2, 0, 2]), 4)
    assert out is not None, "counts returns nothing."
    assert np.shape(out) == (4,), (
        f"With n_arms = 4, the output must have length 4, even if an arm is never played: got shape {np.shape(out)}."
    )
    assert np.array_equal(out, [2, 0, 3, 0]), (
        f"For arms [0, 2, 2, 0, 2] and n_arms = 4, expected [2, 0, 3, 0], got {np.asarray(out).tolist()}."
    )
    _ok("counts")


def check_running_mean(running_mean):
    x = np.array([1.0, 0.0, 1.0, 1.0])
    expected = np.array([1.0, 0.5, 2 / 3, 0.75])
    out = running_mean(x)
    assert out is not None, "running_mean returns nothing."
    assert np.allclose(out, expected), (
        f"For x = {x.tolist()}, expected {expected.round(3).tolist()}, got {np.asarray(out).round(3).tolist()}."
    )
    batch = np.stack([x, 1 - x])
    out = running_mean(batch)
    assert np.shape(out) == (2, 4), "For x of shape (n_runs, T), the output must have the same shape."
    assert np.allclose(out, [expected, 1 - expected]), "The running mean must be computed along the last axis (time)."
    _ok("running_mean")


def check_bernoulli(bernoulli):
    out = bernoulli(0.3, 20000, np.random.default_rng(0))
    assert out is not None, "bernoulli returns nothing."
    out = np.asarray(out)
    assert out.shape == (20000,), f"With size = 20000, the output must have shape (20000,): got {out.shape}."
    assert np.all((out == 0) | (out == 1)), "The values must be 0 or 1."
    assert abs(out.mean() - 0.3) < 0.02, f"With p = 0.3, the mean of the draws must be close to 0.3: got {out.mean():.3f}."
    again = np.asarray(bernoulli(0.3, 20000, np.random.default_rng(0)))
    assert np.array_equal(out, again), "Two calls with generators of the same seed must return the same draws: use `rng` for all random draws."
    out = np.asarray(bernoulli(0.5, (3, 7), np.random.default_rng(1)))
    assert out.shape == (3, 7), f"With size = (3, 7), the output must have shape (3, 7): got {out.shape}."
    _ok("bernoulli")


def check_running_mean_class(RunningMean):
    m = RunningMean()
    assert m.n == 0, "A new RunningMean must have n = 0."
    values = []
    for x in [1.0, 0.0, 1.0, 1.0]:
        m.update(x)
        values.append(m.value)
    assert m.n == 4, f"After 4 updates, n must be 4: got {m.n}."
    assert np.allclose(values, [1.0, 0.5, 2 / 3, 0.75]), (
        f"After the updates 1, 0, 1, 1, the successive values must be [1, 0.5, 0.667, 0.75]: got {np.round(values, 3).tolist()}."
    )
    stored = [v for v in vars(m).values() if isinstance(v, (list, np.ndarray)) and np.size(v) > 1]
    assert not stored, "The past observations must not be stored: keep only n and value."
    _ok("RunningMean")


def check_round_robin(RoundRobinAgent):
    got = _arms(RoundRobinAgent(3), _FixedBandit([0.2, 0.8, 0.5]), 7)
    assert got == [0, 1, 2, 0, 1, 2, 0], f"With 3 arms, expected [0, 1, 2, 0, 1, 2, 0], got {got}."
    _ok("RoundRobinAgent")
