"""Lab framework for the Sequential Decision course (ESIEE Paris)."""

from .bandits import (
    Agent,
    Bandit,
    BernoulliBandit,
    GaussianBandit,
    UniformAgent,
    pseudo_regret,
    run,
    run_many,
)
from .plotting import plot_mean
