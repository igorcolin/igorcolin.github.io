"""Linear bandits: environments, agent interface, interaction loop."""

import numpy as np


class LinearBandit:
    """Linear bandit with Bernoulli rewards.

    At each round, arm a has a feature vector x_a in R^d, given by `features()` as an
    array of shape (n_arms, dim). Pulling arm a pays 1 with probability <theta, x_a> and 0
    otherwise. The parameter `theta` is unknown to the agent.
    """

    def __init__(self, theta, rng=None):
        self.theta = np.asarray(theta, dtype=float)
        self.dim = len(self.theta)
        self.rng = np.random.default_rng(rng)

    def features(self):
        """Feature vectors of the arms at the current round, of shape (n_arms, dim)."""
        raise NotImplementedError

    def means(self):
        """Mean rewards of the arms at the current round."""
        return self.features() @ self.theta

    def pull(self, arm):
        """Pull arm `arm`, return the reward and move to the next round."""
        reward = float(self.rng.random() < self.means()[arm])
        self._next_round()
        return reward

    def _next_round(self):
        pass


class CatalogBandit(LinearBandit):
    """Fixed catalog: item a has the feature vector items[a], the same at every round."""

    def __init__(self, items, theta, rng=None):
        super().__init__(theta, rng)
        self.items = np.asarray(items, dtype=float)
        self.n_arms = len(self.items)

    def features(self):
        return self.items


class RecommendationBandit(LinearBandit):
    """Recommendation with user contexts.

    `appeal[a, j]` is the probability that item a is clicked by a user in mood j. At each
    round a user arrives with a profile `context`, a probability vector over the moods, and
    item a is clicked with probability <context, appeal[a]>. This is a linear bandit of
    dimension n_arms * n_moods: the feature vector of item a is the profile written in
    block a, and zero elsewhere, and theta is the matrix `appeal` flattened.
    """

    def __init__(self, appeal, concentration=0.3, rng=None):
        self.appeal = np.asarray(appeal, dtype=float)
        self.n_arms, self.n_moods = self.appeal.shape
        self.concentration = concentration
        super().__init__(self.appeal.ravel(), rng)
        self._next_round()

    def _next_round(self):
        self.context = self.rng.dirichlet(self.concentration * np.ones(self.n_moods))
        self._features = np.kron(np.eye(self.n_arms), self.context)

    def features(self):
        return self._features


def make_catalog(n_items, dim, rng=None):
    """Random catalog: `n_items` unit feature vectors with nonnegative entries, and a unit
    parameter theta with nonnegative entries, so that all mean rewards lie in [0, 1]."""
    rng = np.random.default_rng(rng)
    items = np.abs(rng.standard_normal((n_items, dim)))
    items /= np.linalg.norm(items, axis=1, keepdims=True)
    theta = np.abs(rng.standard_normal(dim))
    theta /= np.linalg.norm(theta)
    return items, theta


class LinearAgent:
    """Linear bandit agent. Subclasses implement `act` and `update`."""

    def __init__(self, dim, rng=None):
        self.dim = dim
        self.rng = np.random.default_rng(rng)
        self.reset()

    def reset(self):
        self.t = 0

    def act(self, features):
        """Return the arm to play, given the array `features` of shape (n_arms, dim)."""
        raise NotImplementedError

    def update(self, x, arm, reward):
        """Take into account the reward of arm `arm`, whose feature vector is `x`."""
        self.t += 1


class ContextFree(LinearAgent):
    """Wrap a K-armed agent (Labs 1 and 2) so that it plays a linear bandit, ignoring the
    features: each arm index is treated as an unrelated arm."""

    def __init__(self, agent):
        self.agent = agent
        super().__init__(dim=None, rng=agent.rng)

    def reset(self):
        super().reset()
        self.agent.reset()

    def act(self, features):
        return self.agent.act()

    def update(self, x, arm, reward):
        super().update(x, arm, reward)
        self.agent.update(arm, reward)


def run_linear(env, agent, horizon):
    """Let `agent` play on the linear bandit `env` for `horizon` rounds.

    Return three arrays of length `horizon`: arms played, rewards, and instantaneous
    regrets max_a <theta, x_a> - <theta, x_{A_t}>.
    """
    agent.reset()
    arms = np.empty(horizon, dtype=int)
    rewards = np.empty(horizon)
    regrets = np.empty(horizon)
    for t in range(horizon):
        features = env.features()
        arm = agent.act(features)
        if not (isinstance(arm, (int, np.integer)) and 0 <= arm < len(features)):
            raise ValueError(
                f"act() must return an integer between 0 and {len(features) - 1}, "
                f"but returned {arm!r} at round {t + 1}."
            )
        means = features @ env.theta
        reward = env.pull(arm)
        agent.update(features[arm], arm, reward)
        arms[t], rewards[t], regrets[t] = arm, reward, means.max() - means[arm]
    return arms, rewards, regrets


def run_many_linear(make_env, make_agent, horizon, n_runs, seed=0):
    """Repeat `run_linear` over `n_runs` independent and reproducible runs.

    `make_env(rng)` builds the environment and `make_agent(env, rng)` the agent.
    Return the cumulative pseudo-regret, of shape (n_runs, horizon).
    """
    regret = np.empty((n_runs, horizon))
    for i, child in enumerate(np.random.SeedSequence(seed).spawn(n_runs)):
        env_seed, agent_seed = child.spawn(2)
        env = make_env(np.random.default_rng(env_seed))
        agent = make_agent(env, np.random.default_rng(agent_seed))
        regret[i] = np.cumsum(run_linear(env, agent, horizon)[2])
    return regret
