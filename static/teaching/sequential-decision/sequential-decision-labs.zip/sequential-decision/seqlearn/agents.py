"""Reference agents from the previous labs, used as baselines."""

import numpy as np

from .bandits import Agent


class UCBAgent(Agent):
    """UCB(alpha): index mu_hat + sqrt(alpha log t / N). alpha = 2 gives UCB1 (Labs 1 and 2)."""

    def __init__(self, n_arms, alpha=2.0, rng=None):
        self.alpha = alpha
        super().__init__(n_arms, rng)

    def index(self):
        return self.mu_hat + np.sqrt(self.alpha * np.log(self.t + 1) / self.counts)

    def act(self):
        if self.t < self.n_arms:
            return self.t
        return int(np.argmax(self.index()))
