"""Check the installation of the course environment. Usage: python check_install.py"""

import sys


def main():
    print(f"python     {sys.version.split()[0]}  ({sys.executable})")
    if sys.version_info < (3, 11):
        sys.exit("Python 3.11 or later is required: see the setup page.")
    try:
        import matplotlib
        import numpy as np
    except ImportError as error:
        sys.exit(f"{error}. Activate the course environment, then follow the setup page again.")
    print(f"numpy      {np.__version__}")
    print(f"matplotlib {matplotlib.__version__}")
    try:
        import jupyterlab
        print(f"jupyterlab {jupyterlab.__version__}")
    except ImportError:
        print("jupyterlab not found: install it (setup page), or open the notebooks with VS Code.")
    try:
        from seqlearn import BernoulliBandit, UniformAgent, run
    except ImportError:
        sys.exit("seqlearn not found: see \"Common problems\" in the setup page.")
    arms, rewards = run(BernoulliBandit([0.6, 0.4], rng=0), UniformAgent(2, rng=1), horizon=100)
    print(f"seqlearn   test run of 100 rounds, mean reward {rewards.mean():.2f}")
    print("Installation OK.")


if __name__ == "__main__":
    main()
